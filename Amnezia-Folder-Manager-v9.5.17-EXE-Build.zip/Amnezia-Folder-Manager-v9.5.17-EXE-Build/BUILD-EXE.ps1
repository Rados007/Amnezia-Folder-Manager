﻿#Requires -Version 5.1
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $here 'Amnezia-Folder-Manager-v9.5.17.ps1'
$icon = Join-Path $here 'icon.ico'
$dist = Join-Path $here 'dist'
$output = Join-Path $dist 'Amnezia-Folder-Manager-v9.5.17.exe'

try {
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing script: $source" }
    if (-not (Test-Path -LiteralPath $icon -PathType Leaf)) { throw "Missing icon: $icon" }
    if (-not (Test-Path -LiteralPath $dist)) { New-Item -ItemType Directory -Path $dist -Force | Out-Null }

    $module = Get-Module -ListAvailable -Name ps2exe | Sort-Object Version -Descending | Select-Object -First 1
    if (-not $module) {
        Write-Host 'PS2EXE is not installed. Installing for current user from PowerShell Gallery...' -ForegroundColor Yellow
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
        $nuget = Get-PackageProvider -ListAvailable -Name NuGet -ErrorAction SilentlyContinue
        if (-not $nuget) {
            Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope CurrentUser -ErrorAction Stop | Out-Null
        }
        $repo = Get-PSRepository -Name PSGallery -ErrorAction SilentlyContinue
        if (-not $repo) { throw 'PowerShell Gallery is not available. Check network access.' }
        Install-Module -Name ps2exe -Repository PSGallery -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
    }
    Import-Module ps2exe -ErrorAction Stop
    $compiler = Get-Command Invoke-ps2exe -ErrorAction SilentlyContinue
    if (-not $compiler) { $compiler = Get-Command ps2exe -ErrorAction SilentlyContinue }
    if (-not $compiler) { throw 'PS2EXE command was not found after loading the module.' }
    Write-Host 'Building Amnezia Folder Manager v9.5.17...' -ForegroundColor Cyan

    $params = @{
        inputFile = $source
        outputFile = $output
        iconFile = $icon
        noConsole = $true
        STA = $true
        title = 'Amnezia Folder Manager'
        product = 'Amnezia Folder Manager'
        company = 'Rados'
        version = '9.5.17.0'
        copyright = 'Rados'
        ErrorAction = 'Stop'
    }
    # Keep compatibility with older PS2EXE module versions.
    if ($compiler.Parameters.ContainsKey('DPIAware')) { $params.DPIAware = $true }
    & $compiler @params

    if (-not (Test-Path -LiteralPath $output -PathType Leaf)) {
        throw 'PS2EXE finished without creating the output executable.'
    }
    Copy-Item -LiteralPath $icon -Destination (Join-Path $dist 'icon.ico') -Force
    Write-Host ''
    Write-Host 'SUCCESS' -ForegroundColor Green
    Write-Host "EXE: $output"
    Write-Host 'The icon.ico file has also been copied beside the EXE for the app window icon.'
    Write-Host 'Configuration remains in %APPDATA%\AmneziaFolderManager.'
} catch {
    Write-Host ''
    Write-Host ('BUILD FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'See README-RU.txt for troubleshooting.'
    exit 1
}
