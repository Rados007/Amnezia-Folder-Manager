﻿#Requires -Version 5.1

$ErrorActionPreference = "Stop"

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
} catch { }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

try {
    [System.Windows.Forms.Application]::EnableVisualStyles()
    [System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)
} catch { }

Add-Type -Namespace Win32 -Name Dpi -MemberDefinition @'
[DllImport("user32.dll")]
public static extern bool SetProcessDPIAware();
[DllImport("shcore.dll")]
public static extern int SetProcessDpiAwareness(int value);
[DllImport("user32.dll")]
public static extern IntPtr GetDC(IntPtr hWnd);
[DllImport("user32.dll")]
public static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
[DllImport("gdi32.dll")]
public static extern int GetDeviceCaps(IntPtr hdc, int nIndex);
'@

try   { [Win32.Dpi]::SetProcessDpiAwareness(2) | Out-Null }
catch { try { [Win32.Dpi]::SetProcessDPIAware() | Out-Null } catch {} }

function Get-DpiScale {
    try {
        $hdc = [Win32.Dpi]::GetDC([IntPtr]::Zero)
        $dpi = [Win32.Dpi]::GetDeviceCaps($hdc, 88)
        [void][Win32.Dpi]::ReleaseDC([IntPtr]::Zero, $hdc)
        if ($dpi -le 0) { return 1.0 }
        return [double]$dpi / 96.0
    } catch { return 1.0 }
}

$script:DpiScale = Get-DpiScale
if     ($script:DpiScale -lt 1.12) { $script:UiScale = 1.0 }
elseif ($script:DpiScale -lt 1.37) { $script:UiScale = 1.25 }
elseif ($script:DpiScale -lt 1.62) { $script:UiScale = 1.5 }
elseif ($script:DpiScale -lt 1.87) { $script:UiScale = 1.75 }
else                               { $script:UiScale = 2.0 }

function Scaled([int]$v) { return [int][Math]::Round($v * $script:UiScale) }

$AppAuthor  = "Rados"
$AppVersion = "v9.5.17"
$RepoOwner  = "Rados007"
$RepoName   = "Amnezia-Folder-Manager"

# Палитра: глубокий тёмный UI в духе Discord / VS Code
$C = @{
    Bg         = [System.Drawing.Color]::FromArgb(49, 51, 56)
    Panel      = [System.Drawing.Color]::FromArgb(43, 45, 49)
    PanelAlt   = [System.Drawing.Color]::FromArgb(30, 31, 34)
    PanelRaised= [System.Drawing.Color]::FromArgb(35, 36, 40)
    Border     = [System.Drawing.Color]::FromArgb(66, 69, 75)
    BorderSoft = [System.Drawing.Color]::FromArgb(58, 60, 65)
    Text       = [System.Drawing.Color]::FromArgb(242, 243, 245)
    TextMuted  = [System.Drawing.Color]::FromArgb(181, 186, 193)
    TextDim    = [System.Drawing.Color]::FromArgb(148, 155, 164)
    TextGreen  = [System.Drawing.Color]::FromArgb(67, 181, 129)
    Accent     = [System.Drawing.Color]::FromArgb(88, 101, 242)
    AccentSoft = [System.Drawing.Color]::FromArgb(71, 82, 196)
    Btn        = [System.Drawing.Color]::FromArgb(66, 70, 77)
    BtnHover   = [System.Drawing.Color]::FromArgb(80, 85, 94)
    Danger     = [System.Drawing.Color]::FromArgb(237, 66, 69)
    DangerHover= [System.Drawing.Color]::FromArgb(200, 50, 53)
    Green      = [System.Drawing.Color]::FromArgb(35, 165, 90)
    GreenHov   = [System.Drawing.Color]::FromArgb(28, 140, 75)
    Selection  = [System.Drawing.Color]::FromArgb(66, 74, 112)
    Highlight  = [System.Drawing.Color]::FromArgb(88, 101, 242)
}

function Set-NodeColor {
    param($node, $color)
    try {
        if ($null -ne $color -and $color -is [System.Drawing.Color]) {
            $node.ForeColor = $color
        } else {
            $node.ForeColor = $C.Text
        }
    } catch { }
}

# ================== MUTEX ==================
$script:mutex = $null
try {
    $script:mutex = New-Object System.Threading.Mutex($false, "Global\AmneziaFolderManager_SingleInstance_v8")
    if (-not $script:mutex.WaitOne(0)) {
        [void][System.Windows.Forms.MessageBox]::Show(
            "Amnezia Folder Manager уже запущен.`n`nЗакройте предыдущий экземпляр и попробуйте снова.",
            "Повторный запуск",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information)
        try { $script:mutex.Dispose() } catch { }
        exit 0
    }
} catch {
    $script:mutex = $null
}

# ================== ПУТИ ==================

function Get-ScriptDirectory {
    # In a compiled executable, resolve files relative to the EXE rather than
    # the PowerShell compiler's temporary location.
    try {
        $procName = [System.Diagnostics.Process]::GetCurrentProcess().ProcessName
        if ($procName -notmatch '^(powershell|pwsh|powershell_ise)$') {
            $exePath = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
            if ($exePath) { return Split-Path -Parent $exePath }
        }
    } catch { }
    if ($PSScriptRoot) { return $PSScriptRoot }
    try {
        if ($MyInvocation.MyCommand.Path) {
            return Split-Path -Parent $MyInvocation.MyCommand.Path
        }
    } catch { }
    try {
        $asm = [System.Reflection.Assembly]::GetEntryAssembly()
        if ($asm -and $asm.Location) { return Split-Path -Parent $asm.Location }
    } catch { }
    try {
        $proc = [System.Diagnostics.Process]::GetCurrentProcess()
        if ($proc -and $proc.MainModule -and $proc.MainModule.FileName) {
            return Split-Path -Parent $proc.MainModule.FileName
        }
    } catch { }
    return (Get-Location).Path
}

function Test-DirectoryWritable([string]$dir) {
    try {
        if (-not (Test-Path -LiteralPath $dir -PathType Container)) { return $false }
        $probe = Join-Path $dir (".write-test-{0}.tmp" -f ([Guid]::NewGuid().ToString("N")))
        Set-Content -LiteralPath $probe -Value "x" -Encoding ASCII -ErrorAction Stop
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        return $true
    } catch { return $false }
}

$ScriptDir = Get-ScriptDirectory

# User configuration is independent of installation/EXE location.
# Keep exports beside the program when possible, but ALWAYS persist settings in AppData.
$DataDir = Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'AmneziaFolderManager'
if (-not (Test-Path -LiteralPath $DataDir -PathType Container)) {
    New-Item -ItemType Directory -Path $DataDir -Force -ErrorAction Stop | Out-Null
}
if (-not (Test-DirectoryWritable $DataDir)) {
    throw "Cannot write configuration directory: $DataDir"
}
$OutDir = $ScriptDir
if (-not (Test-DirectoryWritable $OutDir)) { $OutDir = $DataDir }

# Migrate v9.2.0 portable settings, but never overwrite existing user settings.
$legacyConfig = Join-Path $ScriptDir 'folders.json'
$legacyBackup = Join-Path $ScriptDir 'folders.json.bak'
$newConfig = Join-Path $DataDir 'folders.json'
if (-not (Test-Path -LiteralPath $newConfig) -and (Test-Path -LiteralPath $legacyConfig)) {
    try {
        $legacyData = Get-Content -LiteralPath $legacyConfig -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if ($legacyData -and $legacyData.PSObject.Properties['Folders']) {
            Copy-Item -LiteralPath $legacyConfig -Destination $newConfig -ErrorAction Stop
            if (Test-Path -LiteralPath $legacyBackup) {
                Copy-Item -LiteralPath $legacyBackup -Destination (Join-Path $DataDir 'folders.json.bak') -ErrorAction SilentlyContinue
            }
        }
    } catch { Write-Warning "Could not migrate legacy settings: $_" }
}

$LogPath    = Join-Path $DataDir "amnezia-fm.log"
$ConfigPath = Join-Path $DataDir "folders.json"
$BackupPath = Join-Path $DataDir "folders.json.bak"

$HistoryDir = Join-Path $DataDir 'History'
$OperationsPath = Join-Path $DataDir 'operations.json'

# Bounded fingerprints of files produced by Folder Manager. Nothing is inserted
# into the AmneziaVPN backup itself; source exports are never modified.
$GeneratedHashesPath = Join-Path $DataDir 'generated-backup-hashes.json'
function Get-BackupSha256([string]$path) {
    $stream = $null
    $sha = $null
    try {
        $stream = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
        $sha = [System.Security.Cryptography.SHA256]::Create()
        return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-','').ToLowerInvariant()
    } finally {
        if ($sha) { $sha.Dispose() }
        if ($stream) { $stream.Dispose() }
    }
}
function Get-GeneratedHashes {
    $result = New-Object 'System.Collections.Generic.List[string]'
    try {
        if (Test-Path -LiteralPath $GeneratedHashesPath -PathType Leaf) {
            $raw = [System.IO.File]::ReadAllText($GeneratedHashesPath, [System.Text.Encoding]::UTF8)
            $parsed = ConvertFrom-Json -InputObject $raw -ErrorAction Stop
            foreach ($record in @($parsed)) {
                if ($null -eq $record) { continue }
                $value = ([string]$record).Trim().ToLowerInvariant()
                if ($value -match '^[a-f0-9]{64}$' -and -not $result.Contains($value)) {
                    [void]$result.Add($value)
                }
            }
        }
    } catch { Write-Log "Could not load output fingerprints: $_" }
    return $result.ToArray()
}
function Register-GeneratedBackup([string]$path) {
    try {
        $hash = Get-BackupSha256 $path
        $values = New-Object 'System.Collections.Generic.List[string]'
        foreach ($knownHash in @(Get-GeneratedHashes)) {
            if ($knownHash -ne $hash) { [void]$values.Add([string]$knownHash) }
        }
        [void]$values.Add($hash)
        while ($values.Count -gt 50) { $values.RemoveAt(0) }
        $tmp = "$GeneratedHashesPath.tmp"
        # Pass an actual string[] to ConvertTo-Json rather than a PowerShell
        # pipeline-generated nested array (which broke the old verification).
        $json = ConvertTo-Json -InputObject ([string[]]$values.ToArray()) -Compress -Depth 3
        [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
        $previousHashes = "$GeneratedHashesPath.old"
        if (Test-Path -LiteralPath $GeneratedHashesPath -PathType Leaf) {
            [System.IO.File]::Replace($tmp, $GeneratedHashesPath, $previousHashes)
            if (Test-Path -LiteralPath $previousHashes -PathType Leaf) {
                Remove-Item -LiteralPath $previousHashes -Force -ErrorAction SilentlyContinue
            }
        } else {
            [System.IO.File]::Move($tmp, $GeneratedHashesPath)
        }
        $savedHashes = @(Get-GeneratedHashes)
        if (-not ($savedHashes -contains $hash)) {
            Write-Log "Fingerprint verification: expected=$hash saved=$($savedHashes.Count) raw=$([System.IO.File]::ReadAllText($GeneratedHashesPath))"
            throw 'Контрольная сумма созданного backup не сохранилась в истории.'
        }
        Write-Log "Контрольная сумма созданного backup зарегистрирована (записей: $($savedHashes.Count))"
    } catch { Write-Log "Could not register generated backup: $_" }
}
function Test-IsGeneratedBackup([string]$path) {
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $false }
    $full = [System.IO.Path]::GetFullPath($path)
    $output = [System.IO.Path]::GetFullPath((Join-Path $OutDir 'Amnezia-UPDATED.backup'))
    if ($full.Equals($output, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    if ([System.IO.Path]::GetFileName($full).Equals('Amnezia-UPDATED.backup', [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    $fingerprints = @(Get-GeneratedHashes)
    if ($fingerprints.Count -eq 0) { return $false }
    $hash = Get-BackupSha256 $full
    return ($fingerprints -contains $hash)
}
function Show-GeneratedBackupWarning {
    $null = [System.Windows.Forms.MessageBox]::Show(
        "Этот backup создан Amnezia Folder Manager и не может использоваться как исходный.`n`nЭкспортируйте актуальный backup непосредственно из AmneziaVPN и откройте его кнопкой «Открыть backup».`n`nЭто защищает от повторной обработки промежуточного результата.",
        'Нужен экспорт из AmneziaVPN',
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Warning)
}

function Trim-BackupHistory {
    try {
        if (-not (Test-Path -LiteralPath $HistoryDir)) { return }
        $files = @(Get-ChildItem -LiteralPath $HistoryDir -Filter '*.backup' -File | Sort-Object LastWriteTime -Descending)
        $total = [long]0
        for ($i = 0; $i -lt $files.Count; $i++) {
            $total += [long]$files[$i].Length
            if ($i -ge 5 -or ($total -gt 100MB -and $i -gt 0)) {
                Remove-Item -LiteralPath $files[$i].FullName -Force -ErrorAction SilentlyContinue
            }
        }
    } catch { Write-Log "History rotation error: $_" }
}
function Write-OperationHistory([string]$operation, [string]$details) {
    try {
        $history = @()
        if (Test-Path -LiteralPath $OperationsPath) {
            $history = @(Get-Content -LiteralPath $OperationsPath -Raw -Encoding UTF8 | ConvertFrom-Json)
        }
        $history += [PSCustomObject]@{
            Time=(Get-Date).ToString('o'); Action=$operation; Details=$details
        }
        $history = @($history | Select-Object -Last 100)
        $temporary = "$OperationsPath.tmp"
        $json = ConvertTo-Json -InputObject @($history) -Depth 10
        [System.IO.File]::WriteAllText($temporary, $json, ([System.Text.UTF8Encoding]::new($false)))
        if (Test-Path -LiteralPath $OperationsPath) {
            # .NET Framework File.Replace rejects a null backup destination on some
            # Windows builds. Use a valid sibling and clean it after a successful swap.
            $operationOld = "$OperationsPath.old"
            [System.IO.File]::Replace($temporary, $OperationsPath, $operationOld)
            if (Test-Path -LiteralPath $operationOld) {
                Remove-Item -LiteralPath $operationOld -Force -ErrorAction SilentlyContinue
            }
        } else { [System.IO.File]::Move($temporary, $OperationsPath) }
    } catch { Write-Log "Operation history failed: $_" }
}
function Show-OperationHistory {
    if (-not (Test-Path -LiteralPath $OperationsPath)) {
        [void][System.Windows.Forms.MessageBox]::Show('История операций пока пуста.')
        return
    }
    try {
        $history = @(Get-Content -LiteralPath $OperationsPath -Raw -Encoding UTF8 | ConvertFrom-Json)
        $text = ($history | Select-Object -Last 100 | ForEach-Object {
            "{0} | {1} | {2}" -f $_.Time, $_.Action, $_.Details
        }) -join "`r`n"
        $dialog = New-Object System.Windows.Forms.Form
        $dialog.Text = 'История операций (последние 100)'
        $dialog.Size = New-Object System.Drawing.Size((Scaled 850),(Scaled 450))
        $dialog.StartPosition = 'CenterParent'
        $box = New-Object System.Windows.Forms.TextBox
        $box.Multiline = $true; $box.ScrollBars = 'Both'; $box.ReadOnly = $true
        $box.WordWrap = $false; $box.Dock = 'Fill'; $box.Text = $text
        $dialog.Controls.Add($box)
        [void]$dialog.ShowDialog($form)
        $dialog.Dispose()
    } catch { [void][System.Windows.Forms.MessageBox]::Show("Не удалось прочитать историю: $_") }
}

function Restore-PreviousBackup {
    $files = @(Get-ChildItem -LiteralPath $HistoryDir -Filter '*.backup' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($files.Count -eq 0) {
        [void][System.Windows.Forms.MessageBox]::Show('Предыдущих backup пока нет.')
        return
    }
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = 'Выберите предыдущий backup (копия будет восстановлена)'
    $dialog.InitialDirectory = $HistoryDir
    $dialog.Filter = 'Amnezia backup (*.backup)|*.backup'
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
    $source = [System.IO.Path]::GetFullPath($dialog.FileName)
    $historyRoot = [System.IO.Path]::GetFullPath($HistoryDir).TrimEnd('\') + '\'
    if (-not $source.StartsWith($historyRoot,[System.StringComparison]::OrdinalIgnoreCase)) {
        [void][System.Windows.Forms.MessageBox]::Show('Можно восстановить только backup из каталога истории.')
        return
    }
    try {
        $check = Get-Content -LiteralPath $source -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $check.PSObject.Properties['Conf/ExceptApps'] -or $check.'Conf/ExceptApps' -isnot [array]) {
            throw 'Некорректная структура backup'
        }
        $target = Join-Path $OutDir 'Amnezia-UPDATED.backup'
        $temp = "$target.restore.tmp"
        Copy-Item -LiteralPath $source -Destination $temp -Force -ErrorAction Stop
        $previous = "$target.previous.backup"
        if (Test-Path -LiteralPath $target) {
            [System.IO.File]::Replace($temp,$target,$previous)
            Save-PreviousBackup $previous
        } else { Move-Item -LiteralPath $temp -Destination $target }
        Write-OperationHistory 'RESTORE' ([System.IO.Path]::GetFileName($source))
        [void][System.Windows.Forms.MessageBox]::Show("Backup восстановлен в:`n$target`n`nДля применения импортируйте его в AmneziaVPN.", 'Восстановление завершено')
    } catch { [void][System.Windows.Forms.MessageBox]::Show("Ошибка восстановления: $_") }
}

function Save-PreviousBackup([string]$previous) {
    if (-not (Test-Path -LiteralPath $previous)) { return }
    try {
        if (-not (Test-Path -LiteralPath $HistoryDir)) {
            [void](New-Item -ItemType Directory -Path $HistoryDir -Force)
        }
        $dest = Join-Path $HistoryDir ('Amnezia-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff') + '.backup')
        Move-Item -LiteralPath $previous -Destination $dest -ErrorAction Stop
        Trim-BackupHistory
    } catch {
        Write-Log "History save error: $_"
        # Do not leave unlimited previous backups in the output directory.
        Remove-Item -LiteralPath $previous -Force -ErrorAction SilentlyContinue
    }
}

function Write-Log($msg) {
    try {
        $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $line = "[$ts] $msg"
        # Keep one bounded log, preserving the newest entries only.
        if (Test-Path -LiteralPath $LogPath) {
            $fi = Get-Item -LiteralPath $LogPath -ErrorAction Stop
            if ($fi.Length -gt 950KB) {
                $lines = @(Get-Content -LiteralPath $LogPath -Encoding UTF8 -ErrorAction Stop)
                $tail = New-Object 'System.Collections.Generic.List[string]'
                $bytes = 0
                for ($i = $lines.Count - 1; $i -ge 0; $i--) {
                    $bytes += [System.Text.Encoding]::UTF8.GetByteCount($lines[$i]) + 2
                    if ($bytes -gt 700KB) { break }
                    $tail.Insert(0, $lines[$i])
                }
                [System.IO.File]::WriteAllLines($LogPath, [string[]]$tail.ToArray(), ([System.Text.UTF8Encoding]::new($false)))
            }
        }
        Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
    } catch { }
}

Trim-BackupHistory
Write-Log "=== START $AppVersion (by $AppAuthor) ==="
Write-Log "DPI=$($script:DpiScale) UiScale=$($script:UiScale)"
Write-Log "ScriptDir=$ScriptDir"
Write-Log "DataDir=$DataDir"
Write-Log "OutDir=$OutDir"

# ================== ХЕЛПЕРЫ ПУТЕЙ ==================

function Normalize-FullPath([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return $path }
    try {
        $path = $path.Trim().Trim('"').Replace('/', '\')
        $full = [System.IO.Path]::GetFullPath($path)
        $root = [System.IO.Path]::GetPathRoot($full)
        if ([string]::Equals($full, $root, [System.StringComparison]::OrdinalIgnoreCase)) { return $full }
        return $full.TrimEnd('\')
    } catch { return $path.TrimEnd('\') }
}
function Get-PathKey([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path)) { return "" }
    return (Normalize-FullPath $path).ToLowerInvariant()
}

function Test-PathWithinFolder([string]$path, [string]$folder) {
    if ([string]::IsNullOrWhiteSpace($path) -or [string]::IsNullOrWhiteSpace($folder)) { return $false }
    try {
        $p = Normalize-FullPath $path
        $f = Normalize-FullPath $folder
    } catch { return $false }
    if ([string]::Equals($p, $f, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    $prefix = if ($f.EndsWith('\')) { $f } else { $f + '\' }
    return $p.StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)
}

function Test-PathInAnyConfiguredFolder([string]$path, $folders) {
    foreach ($folder in @($folders)) {
        if (Test-PathWithinFolder $path $folder) { return $true }
    }
    return $false
}

function Normalize-FolderList($folders) {
    $result = New-Object System.Collections.Generic.List[string]
    $seen = @{}

    foreach ($folder in @($folders)) {
        if ([string]::IsNullOrWhiteSpace([string]$folder)) { continue }
        $full = Normalize-FullPath ([string]$folder)
        $key = $full.ToLowerInvariant()
        if (-not $seen.ContainsKey($key)) {
            $seen[$key] = $true
            [void]$result.Add($full)
        }
    }

    $sorted = @($result | Sort-Object Length)
    $final = New-Object System.Collections.Generic.List[string]

    foreach ($folder in $sorted) {
        $covered = $false
        foreach ($parent in $final) {
            if (Test-PathWithinFolder $folder $parent) {
                $covered = $true
                break
            }
        }
        if (-not $covered) { [void]$final.Add($folder) }
    }

    return @($final)
}

# ================== UI СТИЛИ ==================

# Use the contemporary Windows 11 font when installed, with a reliable Windows 10 fallback.
# Resolve the installed family once rather than probing GDI fonts for every control.
$script:UiFontFamily = 'Segoe UI'
try {
    $installedFonts = New-Object System.Drawing.Text.InstalledFontCollection
    if (@($installedFonts.Families | Where-Object { $_.Name -eq 'Segoe UI Variable' }).Count -gt 0) {
        $script:UiFontFamily = 'Segoe UI Variable'
    }
} catch { }

function New-UiFont([double]$size, [string]$weight = "Regular", [string]$family = "") {
    $style = [System.Drawing.FontStyle]::Regular
    if ($weight -eq "Bold") { $style = [System.Drawing.FontStyle]::Bold }
    if ([string]::IsNullOrWhiteSpace($family)) { $family = $script:UiFontFamily }
    foreach ($candidate in @($family, 'Segoe UI', 'Microsoft Sans Serif')) {
        try {
            $f = New-Object System.Drawing.Font($candidate, [single]($size * $script:UiScale), $style)
            if ($f.FontFamily.Name -eq $candidate) { return $f }
            $f.Dispose()
        } catch { }
    }
    return New-Object System.Drawing.Font([System.Drawing.FontFamily]::GenericSansSerif, [single]($size * $script:UiScale), $style)
}

function Get-HoverColor([System.Drawing.Color]$c) {
    $r = [Math]::Min(255, [int]$c.R + 18)
    $g = [Math]::Min(255, [int]$c.G + 18)
    $b = [Math]::Min(255, [int]$c.B + 18)
    return [System.Drawing.Color]::FromArgb($r, $g, $b)
}

function Get-DownColor([System.Drawing.Color]$c) {
    $r = [Math]::Max(0, [int]$c.R - 18)
    $g = [Math]::Max(0, [int]$c.G - 18)
    $b = [Math]::Max(0, [int]$c.B - 18)
    return [System.Drawing.Color]::FromArgb($r, $g, $b)
}

function Style-FlatButton($btn, $normalColor, $textColor, $hoverColor = $null, $borderColor = $null) {
    $btn.FlatStyle = "Flat"
    if ($null -eq $borderColor) {
        $btn.FlatAppearance.BorderSize = 0
    } else {
        $btn.FlatAppearance.BorderSize = 1
        $btn.FlatAppearance.BorderColor = $borderColor
    }
    if ($null -eq $hoverColor) { $hoverColor = Get-HoverColor $normalColor }
    $btn.FlatAppearance.MouseOverBackColor = $hoverColor
    $btn.FlatAppearance.MouseDownBackColor = (Get-DownColor $normalColor)
    $btn.BackColor = $normalColor
    $btn.ForeColor = $textColor
    $btn.Cursor = "Hand"
    $btn.UseVisualStyleBackColor = $false
    $btn.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $btn.FlatAppearance.BorderSize = 0
}

function Style-PrimaryButton($btn) {
    Style-FlatButton $btn $C.Accent ([System.Drawing.Color]::White) $C.AccentSoft
    $btn.Font = New-UiFont 10 "Bold"
}

function Style-SecondaryButton($btn) {
    Style-FlatButton $btn $C.Btn $C.Text $C.BtnHover $C.BorderSoft
    $btn.Font = New-UiFont 9
}

function Style-DangerButton($btn) {
    Style-FlatButton $btn $C.Danger ([System.Drawing.Color]::White) $C.DangerHover
    $btn.Font = New-UiFont 9 "Bold"
}

function Style-GreenButton($btn) {
    Style-FlatButton $btn $C.Green ([System.Drawing.Color]::White) $C.GreenHov
    $btn.Font = New-UiFont 9 "Bold"
}

function Style-Form($form) {
    $form.BackColor = $C.Bg
    $form.ForeColor = $C.Text
    $form.Font = New-UiFont 9
    $form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
}

function Style-Label($lbl) {
    $lbl.BackColor = $C.Bg
    $lbl.ForeColor = $C.Text
    $lbl.Font = New-UiFont 9
}

function Style-MutedLabel($lbl) {
    $lbl.BackColor = $C.Bg
    $lbl.ForeColor = $C.TextMuted
    $lbl.Font = New-UiFont 8.5
}

function Style-DarkTextBox($ctrl) {
    $ctrl.BackColor = $C.PanelAlt
    $ctrl.ForeColor = $C.Text
    $ctrl.BorderStyle = "FixedSingle"
    $ctrl.Font = New-UiFont 9.5
}

function Style-TreeView($tree) {
    $tree.BackColor = $C.Panel
    $tree.ForeColor = $C.Text
    $tree.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $tree.Font = New-UiFont 9.5
    $tree.ShowLines = $false
    $tree.ShowPlusMinus = $true
    $tree.ShowRootLines = $true
    $tree.HideSelection = $false
    $tree.FullRowSelect = $false
    $tree.LineColor = $C.Border
}

function Set-ButtonOkAction($btn) {
    $btn.Add_Click({
        param($sender, $e)
        try { $f = $sender.FindForm(); if ($f) { $f.DialogResult = [System.Windows.Forms.DialogResult]::OK } } catch { }
        try { $f = $sender.FindForm(); if ($f) { $f.Close() } } catch { }
    })
}

function Set-ButtonCancelAction($btn) {
    $btn.Add_Click({
        param($sender, $e)
        try { $f = $sender.FindForm(); if ($f) { $f.DialogResult = [System.Windows.Forms.DialogResult]::Cancel } } catch { }
        try { $f = $sender.FindForm(); if ($f) { $f.Close() } } catch { }
    })
}

# ================== КОНФИГ ==================

function Load-Config {
    if (Test-Path -LiteralPath $ConfigPath) {
        try {
            $cfg = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if (-not $cfg.PSObject.Properties["Folders"]) {
                $cfg | Add-Member -MemberType NoteProperty -Name "Folders" -Value @() -Force
            }
            if (-not $cfg.PSObject.Properties["Selected"]) {
                $cfg | Add-Member -MemberType NoteProperty -Name "Selected" -Value ([PSCustomObject]@{}) -Force
            }
            if (-not $cfg.PSObject.Properties["LastBackup"]) {
                $cfg | Add-Member -MemberType NoteProperty -Name "LastBackup" -Value "" -Force
            }
            if (-not $cfg.PSObject.Properties["HideIntro"]) {
                $cfg | Add-Member -MemberType NoteProperty -Name "HideIntro" -Value $false -Force
            }
            if (-not $cfg.PSObject.Properties["LastUpdateCheck"]) {
                $cfg | Add-Member -MemberType NoteProperty -Name "LastUpdateCheck" -Value "" -Force
            }
            if (-not $cfg.PSObject.Properties["LatestKnownTag"]) {
                $cfg | Add-Member -MemberType NoteProperty -Name "LatestKnownTag" -Value "" -Force
            }
            if (-not $cfg.PSObject.Properties["WindowGeometry"]) {
                $cfg | Add-Member -MemberType NoteProperty -Name "WindowGeometry" -Value $null -Force
            }
            if (-not $cfg.PSObject.Properties["ExcludedFolders"]) { $cfg | Add-Member NoteProperty ExcludedFolders @() -Force }
            if (-not $cfg.PSObject.Properties["ManagedApps"]) { $cfg | Add-Member NoteProperty ManagedApps @() -Force }
            if (-not $cfg.PSObject.Properties["ManualApps"]) { $cfg | Add-Member NoteProperty ManualApps @() -Force }
            if (-not $cfg.PSObject.Properties["DeletedApps"]) { $cfg | Add-Member NoteProperty DeletedApps @() -Force }
            if (-not $cfg.PSObject.Properties["BackupProfiles"]) { $cfg | Add-Member NoteProperty BackupProfiles @() -Force }
            if (-not $cfg.PSObject.Properties["FolderProvenance"]) { $cfg | Add-Member NoteProperty FolderProvenance @() -Force }
            return $cfg
        } catch {
            Write-Log "Load-Config err: $_"
            if (Test-Path -LiteralPath $BackupPath) {
                try {
                    $recovered = Get-Content -LiteralPath $BackupPath -Raw -Encoding UTF8 | ConvertFrom-Json
                    Write-Log "Конфигурация восстановлена из folders.json.bak"
                    foreach ($kv in @(@("Folders",@()), @("Selected",([PSCustomObject]@{})), @("LastBackup",""), @("ExcludedFolders",@()), @("ManagedApps",@()), @("ManualApps",@()), @("DeletedApps",@()))) {
                        if (-not $recovered.PSObject.Properties[[string]$kv[0]]) { $recovered | Add-Member NoteProperty ([string]$kv[0]) $kv[1] -Force }
                    }
                    if (-not $recovered.PSObject.Properties["BackupProfiles"]) { $recovered | Add-Member NoteProperty BackupProfiles @() -Force }
                    if (-not $recovered.PSObject.Properties["FolderProvenance"]) { $recovered | Add-Member NoteProperty FolderProvenance @() -Force }
                    return $recovered
                } catch {
                    Write-Log "Load backup config err: $_"
                }
            }
        }
    }
    return [PSCustomObject]@{
        ExcludedFolders = @()
        ManagedApps     = @()
        ManualApps      = @()
        DeletedApps     = @()
        BackupProfiles  = @()
        FolderProvenance = @()
        Folders         = @()
        Selected        = [PSCustomObject]@{}
        LastBackup      = ""
        HideIntro       = $false
        LastUpdateCheck = ""
        LatestKnownTag  = ""
        WindowGeometry  = $null
    }
}

function Save-Config($cfg) {
    $tmpPath = "$ConfigPath.tmp"
    try {
        $json = ConvertTo-Json -InputObject $cfg -Depth 50 -ErrorAction Stop
        $roundTrip = $json | ConvertFrom-Json -ErrorAction Stop
        if (-not $roundTrip.PSObject.Properties['Folders'] -or -not $roundTrip.PSObject.Properties['Selected']) {
            throw 'Serialized configuration is missing Folders or Selected'
        }
        [System.IO.File]::WriteAllText($tmpPath, $json, (New-Object System.Text.UTF8Encoding($false)))
        # Avoid losing the last good config if replacement or process termination fails.
        if (Test-Path -LiteralPath $ConfigPath) {
            [System.IO.File]::Replace($tmpPath, $ConfigPath, $BackupPath)
        } else {
            [System.IO.File]::Move($tmpPath, $ConfigPath)
        }
        $saved = Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if (@($saved.Folders).Count -ne @($cfg.Folders).Count) {
            throw 'Config verification failed: folder count differs'
        }
        if (@($saved.ManualApps).Count -ne @($cfg.ManualApps).Count) {
            throw 'Config verification failed: manual EXE count differs'
        }
        Write-Log ("Config saved: folders={0} selected={1} path={2}" -f @($saved.Folders).Count, @($saved.Selected.PSObject.Properties).Count, $ConfigPath)
        return $true
    } catch {
        Write-Log "Save-Config err: $_"
        return $false
    } finally {
        if (Test-Path -LiteralPath $tmpPath) {
            Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue
        }
    }
}


# ================== СКАНИРОВАНИЕ ==================

function Test-IsExcluded([string]$path) {
    foreach ($folder in @($script:excludedFolders)) {
        if (Test-PathWithinFolder $path $folder) { return $true }
    }
    return $false
}
function Get-ExeFiles {
    param([string]$folder, $onProgress = $null)
    $result = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
    $root = Normalize-FullPath $folder
    $rootKey = Get-PathKey $root
    $script:scanState[$rootKey] = 'OK'
    if (-not (Test-Path -LiteralPath $root -PathType Container)) {
        $script:scanState[$rootKey] = 'UNAVAILABLE'; return @()
    }
    $queue = New-Object 'System.Collections.Generic.Queue[string]'
    $queue.Enqueue($root)
    $scanned = 0
    while ($queue.Count -gt 0) {
        $current = $queue.Dequeue()
        if (Test-IsExcluded $current) { continue }
        $scanned++
        if ($onProgress -and ($scanned % 50 -eq 0)) {
            try { & $onProgress $scanned $result.Count } catch { }
        }
        try {
            foreach ($dirPath in [System.IO.Directory]::EnumerateDirectories($current)) {
                $dir = [System.IO.DirectoryInfo]::new($dirPath)
                if (($dir.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                if (-not (Test-IsExcluded $dir.FullName)) { $queue.Enqueue($dir.FullName) }
            }
        } catch { $script:scanState[$rootKey] = 'PARTIAL'; Write-Log "Scan folders error: $current — $_" }
        try {
            foreach ($filePath in [System.IO.Directory]::EnumerateFiles($current, '*.exe')) {
                $file = [System.IO.FileInfo]::new($filePath)
                if (($file.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                [void]$result.Add($file)
            }
        } catch { $script:scanState[$rootKey] = 'PARTIAL'; Write-Log "Scan files error: $current — $_" }
    }
    if ($onProgress) { try { & $onProgress $scanned $result.Count } catch { } }
    return @($result | Sort-Object -Property FullName -Unique)
}


function Format-Size($bytes) {
    if ($bytes -ge 1TB) { return ("{0:N2} ТБ" -f ($bytes/1TB)) }
    if ($bytes -ge 1GB) { return ("{0:N2} ГБ" -f ($bytes/1GB)) }
    if ($bytes -ge 1MB) { return ("{0:N2} МБ" -f ($bytes/1MB)) }
    if ($bytes -ge 1KB) { return ("{0:N1} КБ" -f ($bytes/1KB)) }
    return "$bytes Б"
}

# ================== КЭШ EXE ==================

$script:exeCache = @{}

function Invalidate-ExeCache {
    $script:exeCache = @{}
    $script:scanState = @{}
    Write-Log "ExeCache invalidated"
}

function Get-CachedExeFiles {
    param(
        [string]$folder,
        $onProgress = $null
    )
    $folderKey = Get-PathKey $folder

    if ($script:exeCache.ContainsKey($folderKey)) {
        $entry = $script:exeCache[$folderKey]
        if ($null -ne $entry.Files) {
            return @($entry.Files)
        }
    }

    $files = @(Get-ExeFiles -folder $folder -onProgress $onProgress)
    # Incomplete scans must be retried; do not cache a partial result.
    if ($script:scanState[$folderKey] -ne 'OK') { return $files }
    $script:exeCache[$folderKey] = @{
        Files = $files
    }
    return $files
}

# ================== ОБНОВЛЕНИЯ ==================

function Test-VersionString([string]$a, [string]$b) {
    try {
        $ca = $a.TrimStart('v','V').Split('.')
        $cb = $b.TrimStart('v','V').Split('.')
        $n = [Math]::Max($ca.Count, $cb.Count)
        for ($i = 0; $i -lt $n; $i++) {
            $x = 0; $y = 0
            if ($i -lt $ca.Count) { [void][int]::TryParse($ca[$i], [ref]$x) }
            if ($i -lt $cb.Count) { [void][int]::TryParse($cb[$i], [ref]$y) }
            if ($x -gt $y) { return $true }
            if ($x -lt $y) { return $false }
        }
        return $false
    } catch { return $false }
}

function Get-LatestRelease {
    try {
        $url = "https://api.github.com/repos/$RepoOwner/$RepoName/releases/latest"
        $headers = @{ "User-Agent" = "AmneziaFolderManager" }
        $resp = Invoke-RestMethod -Uri $url -Headers $headers -TimeoutSec 5 -ErrorAction Stop
        return $resp
    } catch {
        return $null
    }
}

# ================== ИНСТРУКЦИЯ ==================

function Show-IntroWindow($showCheckbox) {
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "Amnezia Folder Manager — инструкция"
    $form.Size = New-Object System.Drawing.Size((Scaled 760), (Scaled 640))
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    Style-Form $form
    $form.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

    $rtb = New-Object System.Windows.Forms.RichTextBox
    $rtb.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 12))
    $rtb.Size = New-Object System.Drawing.Size((Scaled 720), (Scaled 520))
    $rtb.ReadOnly = $true
    $rtb.BorderStyle = "FixedSingle"
    $rtb.BackColor = $C.PanelAlt
    $rtb.ForeColor = $C.Text
    $rtb.Font = New-UiFont 10
    $rtb.WordWrap = $true
    $rtb.ScrollBars = "Vertical"
    $form.Controls.Add($rtb)

    $colHeading = [System.Drawing.Color]::FromArgb(120, 140, 255)
    $colMuted   = [System.Drawing.Color]::FromArgb(148, 155, 164)
    $colText    = [System.Drawing.Color]::FromArgb(219, 222, 225)
    $fontNormal = New-UiFont 10
    $fontBold   = New-UiFont 10 "Bold"
    $fontHead   = New-UiFont 12 "Bold"
    $fontItalic = New-Object System.Drawing.Font($script:UiFontFamily, [single](9 * $script:UiScale), [System.Drawing.FontStyle]::Italic)

    function Add-Line([string]$text, $font, $color) {
        try { $rtb.SelectionFont  = $font } catch { }
        try { $rtb.SelectionColor = $color } catch { }
        $rtb.AppendText("$text`n")
        try { $rtb.SelectionFont  = $fontNormal } catch { }
        try { $rtb.SelectionColor = $colText } catch { }
    }

    function Add-Heading([string]$text)    { Add-Line $text $fontHead $colHeading }
    function Add-Subheading([string]$text) { Add-Line $text $fontBold $colHeading }
    function Add-Paragraph([string]$text)  { Add-Line $text $fontNormal $colText }
    function Add-Author([string]$text)     { Add-Line $text $fontItalic $colMuted }
    function Add-Spacer { $rtb.AppendText("`n") }

    Add-Heading "Amnezia Folder Manager $AppVersion"
    Add-Author "Автор: $AppAuthor  |  Руководство пользователя"
    Add-Spacer

    Add-Heading "Для чего нужна программа"
    Add-Paragraph "Folder Manager формирует резервную копию AmneziaVPN со списком приложений, которые должны обходить VPN при использовании режима исключений приложений (split tunneling). Она не меняет настройки работающего клиента напрямую: результат нужно импортировать в AmneziaVPN."
    Add-Spacer

    Add-Heading "Быстрый старт — 5 шагов"
    Add-Paragraph "1. В AmneziaVPN экспортируйте актуальную резервную копию подключения. Повторяйте экспорт перед КАЖДЫМ новым обновлением через Folder Manager."
    Add-Paragraph "2. Нажмите «+ Добавить папку» и выберите каталог с программами или играми. Вложенные каталоги сканируются автоматически."
    Add-Paragraph "3. Настройте галочки в дереве: отмеченные EXE утилита будет поддерживать в списке исключений VPN."
    Add-Paragraph "4. Нажмите «Создать backup», вручную выберите только что экспортированный файл и изучите список изменений. Нажмите «Создать backup» в окне подтверждения."
    Add-Paragraph "5. Импортируйте полученный файл Amnezia-UPDATED.backup в AmneziaVPN и проверьте список исключений приложений."
    Add-Spacer

    Add-Heading "Галочки и маршрутизация"
    Add-Paragraph "Галочка у EXE: Folder Manager добавляет его в исключения AmneziaVPN, то есть предполагается работа приложения БЕЗ VPN в соответствующем режиме клиента."
    Add-Paragraph "Снятая галочка: программа не добавляет этот EXE; если он ранее был добавлен самим Folder Manager, при следующем создании backup она может удалить его из управляемых исключений."
    Add-Paragraph "Галочка у папки действует на файлы внутри неё. Поиск сверху фильтрует отображение дерева. Настройки маршрутизации в самом AmneziaVPN также влияют на итоговое поведение."
    Add-Spacer

    Add-Heading "Игру нужно оставить В VPN?"
    Add-Paragraph "Найдите её папку в дереве, нажмите правой кнопкой мыши и выберите «Пропускать эту папку и всё внутри». Все вложенные EXE перестанут сканироваться и автоматически добавляться в исключения VPN."
    Add-Paragraph "Пропущенная папка остаётся видимой с меткой [ПРОПУСК]. Через правую кнопку её можно вернуть в сканирование. Не путайте «пропустить при сканировании» с удалением папки или файлов с диска — ничего с диска не удаляется."
    Add-Paragraph "Ранее добавленные Folder Manager исключения из такой папки убираются из нового backup. Если аналогичный EXE был добавлен вручную в клиенте AmneziaVPN, его запись может остаться: проверьте список в клиенте."
    Add-Spacer

    Add-Heading "Новые и удалённые EXE"
    Add-Paragraph "При обновлении базы или подготовке backup программа заново проверяет отслеживаемые каталоги. Новые найденные EXE по умолчанию отмечаются. Ранее управляемые исключения могут быть убраны из нового backup, если файл удалён, папка исключена или галочка снята."
    Add-Paragraph "Если сканирование папки завершилось с ошибкой или каталог временно недоступен, данные защищаются от очистки по неполному результату. Перед записью backup можно посмотреть планируемые добавления и удаления."
    Add-Spacer

    Add-Heading "Не потеряются ли ручные исключения?"
    Add-Paragraph "Записи, добавленные вручную через AmneziaVPN, сохраняются из выбранного исходного backup, если Folder Manager не распознаёт их как ранее управляемые им записи. Для точного сохранения ручных изменений всегда сначала делайте НОВЫЙ экспорт из самого AmneziaVPN."
    Add-Paragraph "Если EXE с одним путём ранее управлялся Folder Manager, программа не всегда может отличить его от ручной записи. Перед подтверждением внимательно просматривайте удаления."
    Add-Spacer

    Add-Heading "Обновить базу или создать backup?"
    Add-Paragraph "«Обновить базу» (меню правой кнопки мыши в дереве) — пересканировать папки и обновить внутренний список EXE. Файл для AmneziaVPN при этом НЕ создаётся."
    Add-Paragraph "«Создать backup» — выбрать свежий экспорт AmneziaVPN, пересканировать файлы, показать предварительный просмотр, объединить списки и создать итоговый backup для импорта."
    Add-Spacer

    Add-Heading "Файлы и безопасность"
    Add-Paragraph "Amnezia-UPDATED.backup — один итоговый файл, который обновляется при последующих успешных экспортах. Исходный выбранный файл не должен перезаписываться."
    Add-Paragraph "folders.json хранит папки, галочки и правила. folders.json.bak — страховочная копия настроек. amnezia-fm.log — ограниченный журнал диагностики. Не удаляйте folders.json, если хотите сохранить настройки."
    Add-Paragraph "Резервная копия AmneziaVPN может содержать ключи подключения и другие секреты. Не публикуйте её в открытом доступе. Перед импортом нового backup полезно сохранить отдельную рабочую копию из клиента."
    Add-Spacer

    Add-Heading "Если результат не виден в AmneziaVPN"
    Add-Paragraph "Убедитесь, что импортировали именно новый Amnezia-UPDATED.backup, выбрали нужное подключение и открыли раздел исключений приложений. Если список не изменился, сохраните исходный экспорт и журнал, прежде чем повторять операцию."
    Add-Spacer
    Add-Author "© 2026 $AppAuthor"

    $rtb.SelectionStart = 0
    $rtb.SelectionLength = 0

    $chk = $null
    if ($showCheckbox) {
        $chk = New-Object System.Windows.Forms.CheckBox
        $chk.Text = "Больше не показывать это окно при запуске"
        $chk.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 545))
        $chk.Width = (Scaled 500)
        $chk.Height = (Scaled 24)
        $chk.BackColor = $C.Bg
        $chk.ForeColor = $C.Text
        $form.Controls.Add($chk)
    }

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = "Понятно"
    $btnOk.Width = (Scaled 130)
    $btnOk.Height = (Scaled 34)
    $btnOk.Anchor = "Bottom,Right"
    $btnOk.Location = New-Object System.Drawing.Point((Scaled 600), (Scaled 540))
    Style-PrimaryButton $btnOk
    $btnOk.Font = New-UiFont 10 "Bold"
    $form.Controls.Add($btnOk)
    Set-ButtonOkAction $btnOk

    $form.Add_Shown({
        $btnOk.Left = $form.ClientSize.Width - $btnOk.Width - (Scaled 12)
        $btnOk.Top  = $form.ClientSize.Height - $btnOk.Height - (Scaled 12)
        if ($chk) { $chk.Top = $btnOk.Top + [int](($btnOk.Height - $chk.Height) / 2) }
    })

    [void]$form.ShowDialog()
    $checked = $false
    if ($chk -and $form.DialogResult -eq [System.Windows.Forms.DialogResult]::OK) {
        $checked = $chk.Checked
    }
    $form.Dispose()
    return $checked
}

# ================== MAIN ==================
Write-Log "Loading config"
$cfg = Load-Config

$script:folders    = @(Normalize-FolderList $cfg.Folders)
$script:lastBackup = ""
if ($cfg.LastBackup) {
    $candidateLast = [string]$cfg.LastBackup
    if ((Test-Path -LiteralPath $candidateLast -PathType Leaf) -and -not (Test-IsGeneratedBackup $candidateLast)) {
        $script:lastBackup = $candidateLast
    }
}
$script:hideIntro  = $false
if ($cfg.PSObject.Properties["HideIntro"]) { $script:hideIntro = [bool]$cfg.HideIntro }

$script:selected = [PSCustomObject]@{}
if ($cfg.Selected) {
    foreach ($p in $cfg.Selected.PSObject.Properties) {
        $script:selected | Add-Member -MemberType NoteProperty -Name $p.Name -Value ([bool]$p.Value) -Force
    }
}

$script:excludedFolders = @($cfg.ExcludedFolders | Where-Object { $_ })
$script:managedApps = @($cfg.ManagedApps | Where-Object { $_ })
$script:manualApps = @($cfg.ManualApps | Where-Object { $_ })
$script:sourceBackupPath = $null  # Explicitly opened backup for editing/export
$script:deletedApps = @($cfg.DeletedApps | Where-Object { $_ })
# Backup-local state: no EXE from a different Amnezia export may leak into this one.
$script:backupProfiles = @($cfg.BackupProfiles | Where-Object { $_ -and $_.Path })
$script:folderProvenance = @($cfg.FolderProvenance | Where-Object { $_ -and $_.Path })
$script:activeProfileKey = ''
$script:legacyProfile = [PSCustomObject]@{
    Selected = $cfg.Selected
    ManualApps = @($cfg.ManualApps | Where-Object { $_ })
    ManagedApps = @($cfg.ManagedApps | Where-Object { $_ })
    DeletedApps = @($cfg.DeletedApps | Where-Object { $_ })
}
$script:legacyBackupKey = if ($script:lastBackup) { Get-PathKey $script:lastBackup } else { '' }

$script:scanState = @{}
$script:treeUpdating      = $false
$script:saveDebounceTimer = $null
$script:pendingSave       = $false
$script:lastRebuild       = $null
$script:exeCache          = @{}
$script:filterIsPlaceholder = $true
$script:filterPlaceholder  = "поиск по имени..."

if (-not $script:hideIntro) {
    $userChecked = Show-IntroWindow $true
    if ($userChecked) {
        $script:hideIntro = $true
        $cfg.HideIntro = $true
        Save-Config $cfg
        Write-Log "Инструкция отключена пользователем"
    } else {
        Write-Log "Инструкция показана"
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "Amnezia Folder Manager $AppVersion — by $AppAuthor"
$form.Size = New-Object System.Drawing.Size((Scaled 1000), (Scaled 840))
$form.MinimumSize = New-Object System.Drawing.Size((Scaled 840), (Scaled 700))
$form.StartPosition = "CenterScreen"
Style-Form $form
try {
    $iconPath = Join-Path $ScriptDir "icon.ico"
    if (Test-Path -LiteralPath $iconPath) { $form.Icon = New-Object System.Drawing.Icon($iconPath) }
} catch { Write-Log "Не удалось загрузить иконку окна: $_" }
$form.AllowDrop = $true
$form.KeyPreview = $true

$form.Add_KeyDown({
    param($sender, $e)
    # Ctrl+F — фокус в фильтр
    if ($e.Control -and $e.KeyCode -eq [System.Windows.Forms.Keys]::F) {
        $e.Handled = $true
        if ($script:filterIsPlaceholder) {
            $txtMainFilter.Text = ""
            $txtMainFilter.ForeColor = $C.Text
            $script:filterIsPlaceholder = $false
        }
        $txtMainFilter.Focus()
        $txtMainFilter.SelectAll()
        return
    }
    # Escape — очистить фильтр, не затрагивая выбранные приложения.
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Escape -and $txtMainFilter.Focused) {
        $e.Handled = $true
        $txtMainFilter.Text = ""
        return
    }
    # F5 — обновить базу
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::F5) {
        $e.Handled = $true
        Log "=== F5: Обновить всю базу ==="
        $res = Do-UpdateOnly
        Log "Новых EXE: $($res.New); удалено отсутствующих: $($res.Removed)"
        return
    }
    # Delete — удалить выбранную папку
    if ($e.KeyCode -eq [System.Windows.Forms.Keys]::Delete) {
        if ($txtMainFilter.Focused) { return }
        $e.Handled = $true
        Remove-SelectedFolder
        return
    }
})

# Восстановление геометрии окна
try {
    if ($cfg.WindowGeometry) {
        $g = $cfg.WindowGeometry
        if ($g.Width -gt 200 -and $g.Height -gt 200) {
            $form.StartPosition = "Manual"
            $form.Width  = [int]$g.Width
            $form.Height = [int]$g.Height
            if ($null -ne $g.Left -and $null -ne $g.Top) {
                $form.Left = [int]$g.Left
                $form.Top  = [int]$g.Top
            }
            if ($g.WindowState -eq "Maximized") {
                $form.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
            }
        }
    }
} catch { Write-Log "Restore geometry err: $_" }

$form.Add_FormClosing({
    try {
        if ($script:saveDebounceTimer) {
            $script:saveDebounceTimer.Stop()
            $script:saveDebounceTimer.Dispose()
            $script:saveDebounceTimer = $null
        }
    } catch { }
    try {
        if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Normal) {
            $cfg.WindowGeometry = [PSCustomObject]@{
                Width       = $form.Width
                Height      = $form.Height
                Left        = $form.Left
                Top         = $form.Top
                WindowState = "Normal"
            }
        } else {
            $cfg.WindowGeometry = [PSCustomObject]@{
                Width       = $form.RestoreBounds.Width
                Height      = $form.RestoreBounds.Height
                Left        = $form.RestoreBounds.Left
                Top         = $form.RestoreBounds.Top
                WindowState = $form.WindowState.ToString()
            }
        }
    } catch { }
    try {
        Save-State
    } catch {
        Write-Log "FormClosing Save-State error: $_"
    }
})

# ---- Верхняя панель (фильтр) ----
$pnlTop = New-Object System.Windows.Forms.Panel
$pnlTop.Location = New-Object System.Drawing.Point(0, 0)
$pnlTop.Size = New-Object System.Drawing.Size((Scaled 1000), (Scaled 48))
$pnlTop.Anchor = "Top,Left,Right"
$pnlTop.BackColor = $C.PanelRaised
$form.Controls.Add($pnlTop)

# Discord-style accent separator under the toolbar. No application state involved.
$pnlAccent = New-Object System.Windows.Forms.Panel
$pnlAccent.Location = New-Object System.Drawing.Point(0, (Scaled 46))
$pnlAccent.Size = New-Object System.Drawing.Size((Scaled 1000), (Scaled 2))
$pnlAccent.Anchor = 'Top,Left,Right'
$pnlAccent.BackColor = $C.Accent
$pnlTop.Controls.Add($pnlAccent)

$lblMainFilter = New-Object System.Windows.Forms.Label
$lblMainFilter.Text = "Поиск"
$lblMainFilter.Location = New-Object System.Drawing.Point((Scaled 14), (Scaled 12))
$lblMainFilter.Size = New-Object System.Drawing.Size((Scaled 70), (Scaled 24))
$lblMainFilter.BackColor = $C.PanelRaised
$lblMainFilter.ForeColor = $C.TextMuted
$lblMainFilter.Font = New-UiFont 10 "Bold"
$lblMainFilter.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$pnlTop.Controls.Add($lblMainFilter)

$txtMainFilter = New-Object System.Windows.Forms.TextBox
$txtMainFilter.Location = New-Object System.Drawing.Point((Scaled 90), (Scaled 10))
$txtMainFilter.Width = (Scaled 400)
$txtMainFilter.Height = (Scaled 28)
Style-DarkTextBox $txtMainFilter
$txtMainFilter.Text = "Найти папку или EXE..."
$txtMainFilter.ForeColor = $C.TextDim
$script:filterIsPlaceholder = $true
$script:filterPlaceholder = "Найти папку или EXE..."
$pnlTop.Controls.Add($txtMainFilter)

$txtMainFilter.Add_GotFocus({
    if ($script:filterIsPlaceholder) {
        $txtMainFilter.Text = ""
        $txtMainFilter.ForeColor = $C.Text
        $script:filterIsPlaceholder = $false
    }
})
$txtMainFilter.Add_LostFocus({
    if ([string]::IsNullOrWhiteSpace($txtMainFilter.Text)) {
        $script:filterIsPlaceholder = $true
        $txtMainFilter.Text = $script:filterPlaceholder
        $txtMainFilter.ForeColor = $C.TextDim
    }
})

# Маленькая кнопка «?» (инструкция)
$btnHelp = New-Object System.Windows.Forms.Button
$btnHelp.Text = "?"
$btnHelp.AccessibleName = "Открыть справку"
$btnHelp.Width = (Scaled 34)
$btnHelp.Height = (Scaled 28)
$btnHelp.Location = New-Object System.Drawing.Point((Scaled 720), (Scaled 10))
Style-SecondaryButton $btnHelp
$btnHelp.Font = New-UiFont 11 "Bold"
$pnlTop.Controls.Add($btnHelp)

# ---- Кнопка Добавить (под фильтром, слева) ----
$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = "+  Добавить папку"
$btnAdd.AccessibleName = "Добавить папку в отслеживание"
$btnAdd.Width = (Scaled 180)
$btnAdd.Height = (Scaled 32)
$btnAdd.Anchor = "Top,Left"
$btnAdd.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 56))
Style-PrimaryButton $btnAdd
$btnAdd.Font = New-UiFont 9.5 "Bold"
$form.Controls.Add($btnAdd)

# ---- Навигация и действия в стиле Discord ----
$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = "Обновить список  (F5)"
$btnRefresh.AccessibleName = "Повторно просканировать выбранные папки"
$btnRefresh.Size = New-Object System.Drawing.Size((Scaled 190), (Scaled 32))
$btnRefresh.Location = New-Object System.Drawing.Point((Scaled 202), (Scaled 56))
Style-SecondaryButton $btnRefresh
$form.Controls.Add($btnRefresh)

$lblTreeSection = New-Object System.Windows.Forms.Label
$lblTreeSection.Text = "Приложения / папки"
$lblTreeSection.Location = New-Object System.Drawing.Point((Scaled 14), (Scaled 102))
$lblTreeSection.Size = New-Object System.Drawing.Size((Scaled 290), (Scaled 21))
$lblTreeSection.Font = New-UiFont 9.5 "Bold"
$lblTreeSection.ForeColor = $C.TextMuted
$lblTreeSection.BackColor = $C.Bg
$form.Controls.Add($lblTreeSection)

$lblTreeHint = New-Object System.Windows.Forms.Label
$lblTreeHint.Text = "Галочки определяют, какие EXE попадут в backup"
$lblTreeHint.AutoEllipsis = $true
$lblTreeHint.TextAlign = [System.Drawing.ContentAlignment]::MiddleRight
$lblTreeHint.Location = New-Object System.Drawing.Point((Scaled 430), (Scaled 102))
$lblTreeHint.Size = New-Object System.Drawing.Size((Scaled 538), (Scaled 21))
$lblTreeHint.Font = New-UiFont 8
$lblTreeHint.ForeColor = $C.TextDim
$lblTreeHint.BackColor = $C.Bg
$form.Controls.Add($lblTreeHint)

# ---- Дерево ----
$tree = New-Object System.Windows.Forms.TreeView
$tree.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 130))
$tree.Size = New-Object System.Drawing.Size((Scaled 960), (Scaled 346))
$tree.Anchor = "Top,Left,Right"
$tree.CheckBoxes = $true
$tree.HideSelection = $false
$tree.ShowLines = $false
$tree.ShowRootLines = $true
$tree.ShowPlusMinus = $true
$tree.Indent = Scaled 22
$tree.ItemHeight = Scaled 24
$tree.AllowDrop = $true
Style-TreeView $tree
$form.Controls.Add($tree)

# ---- Панель статистики ----
$pnlStats = New-Object System.Windows.Forms.Panel
$pnlStats.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 484))
$pnlStats.Size = New-Object System.Drawing.Size((Scaled 960), (Scaled 44))
$pnlStats.Anchor = "Top,Left,Right"
$pnlStats.BackColor = $C.Panel
$form.Controls.Add($pnlStats)

$lblInfo = New-Object System.Windows.Forms.Label
$lblInfo.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 4))
$lblInfo.Size = New-Object System.Drawing.Size((Scaled 920), (Scaled 20))
$lblInfo.Anchor = "Top,Left,Right"
$lblInfo.Text = "Готово."
$lblInfo.BackColor = $C.Panel
$lblInfo.ForeColor = $C.Text
$lblInfo.Font = New-UiFont 9
$pnlStats.Controls.Add($lblInfo)

$lblLast = New-Object System.Windows.Forms.Label
$lblLast.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 22))
$lblLast.Size = New-Object System.Drawing.Size((Scaled 920), (Scaled 18))
$lblLast.Anchor = "Top,Left,Right"
$lblLast.Text = "Последний использованный backup: (не указан)"
$lblLast.BackColor = $C.Panel
$lblLast.ForeColor = $C.TextMuted
$lblLast.Font = New-UiFont 8
$pnlStats.Controls.Add($lblLast)

# ---- Backup (слева под деревом/статистикой) ----
# First open the backup, then edit the EXE selection in the tree.
$btnOpenBackup = New-Object System.Windows.Forms.Button
$btnOpenBackup.Text = "Открыть backup"
$btnOpenBackup.AccessibleName = "Открыть backup AmneziaVPN для редактирования списка EXE"
$btnOpenBackup.Width = (Scaled 175)
$btnOpenBackup.Height = (Scaled 40)
$btnOpenBackup.Anchor = "Top,Left"
$btnOpenBackup.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 538))
Style-SecondaryButton $btnOpenBackup
$btnOpenBackup.Font = New-UiFont 10 "Bold"
$form.Controls.Add($btnOpenBackup)

$btnBackup = New-Object System.Windows.Forms.Button
$btnBackup.Text = "Создать backup Amnezia"
$btnBackup.AccessibleName = "Создать резервную копию для AmneziaVPN"
$btnBackup.Width = (Scaled 240)
$btnBackup.Height = (Scaled 40)
$btnBackup.Anchor = "Top,Left"
$btnBackup.Location = New-Object System.Drawing.Point((Scaled 200), (Scaled 538))
Style-PrimaryButton $btnBackup
$btnBackup.Font = New-UiFont 11 "Bold"
$form.Controls.Add($btnBackup)

# ---- Журнал ----
$lblLog = New-Object System.Windows.Forms.Label
$lblLog.Text = "Журнал событий"
$lblLog.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 590))
$lblLog.Size = New-Object System.Drawing.Size((Scaled 160), (Scaled 18))
$lblLog.Anchor = "Top,Left"
Style-MutedLabel $lblLog
$lblLog.Font = New-UiFont 9.5 "Bold"
$form.Controls.Add($lblLog)

$lblLogHint = New-Object System.Windows.Forms.Label
$lblLogHint.Text = "двойной клик — полный лог"
$lblLogHint.Location = New-Object System.Drawing.Point((Scaled 180), (Scaled 590))
$lblLogHint.Size = New-Object System.Drawing.Size((Scaled 280), (Scaled 18))
$lblLogHint.Anchor = "Top,Left"
$lblLogHint.BackColor = $C.Bg
$lblLogHint.ForeColor = $C.TextDim
$lblLogHint.Font = New-UiFont 8
$form.Controls.Add($lblLogHint)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Multiline = $true
$txtLog.ScrollBars = "Vertical"
$txtLog.ReadOnly = $true
$txtLog.Location = New-Object System.Drawing.Point((Scaled 12), (Scaled 612))
$txtLog.Size = New-Object System.Drawing.Size((Scaled 960), (Scaled 220))
$txtLog.Anchor = "Top,Bottom,Left,Right"
$txtLog.BackColor = $C.PanelAlt
$txtLog.ForeColor = $C.TextMuted
$txtLog.BorderStyle = "FixedSingle"
$txtLog.Font = New-UiFont 9 "Regular" "Consolas"
$txtLog.Cursor = "Hand"
$txtLog.Add_DoubleClick({
    try {
        if (Test-Path -LiteralPath $LogPath) { Start-Process notepad.exe $LogPath }
        else { [void][System.Windows.Forms.MessageBox]::Show("Лог-файл ещё не создан.", "Журнал") }
    } catch { Write-Log "Не удалось открыть лог: $_" }
})
$form.Controls.Add($txtLog)

$script:txtLog = $txtLog

function Log($msg) {
    $ts = Get-Date -Format "HH:mm:ss"
    $txtLog.AppendText("[$ts] $msg`r`n")
    Write-Log $msg
}

function Count-Selection {
    # Only active scan roots and visible manual EXEs are counted. Selected also
    # contains historical keys used for old-backup suppression and must never
    # be used directly for the user-facing tree counters.
    $known = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($folder in @($script:folders)) {
        if ($script:scanState[(Get-PathKey $folder)] -ne 'OK') { continue }
        foreach ($fi in @(Get-CachedExeFiles -folder $folder)) {
            if ($fi -and $fi.FullName -and -not (Test-IsExcluded $fi.FullName)) {
                [void]$known.Add((Get-PathKey $fi.FullName))
            }
        }
    }
    $suppressed = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($path in @($script:deletedApps)) { if ($path) { [void]$suppressed.Add((Get-PathKey $path)) } }
    foreach ($path in @($script:manualApps)) {
        if (-not $path -or (Test-PathInAnyConfiguredFolder $path $script:folders)) { continue }
        $key = Get-PathKey $path
        if ($suppressed.Contains($key)) { continue }
        [void]$known.Add($key)
    }
    $checked = 0
    foreach ($key in $known) {
        $p = $script:selected.PSObject.Properties[$key]
        if ($p -and [bool]$p.Value) { $checked++ }
    }
    return @{ Total = $known.Count; Checked = $checked }
}

function Folder-Missing($folder) {
    return (-not (Test-Path -LiteralPath $folder -PathType Container))
}

function Update-InfoLabel {
    try {
        $c = Count-Selection
        $lblInfo.Text = "Папок: $($script:folders.Count)    ·    EXE: $($c.Total)    ·    Отмечено: $($c.Checked)"
    } catch { }
}

function Set-UiBusy {
    param([bool]$Busy, [string]$Status)
    try {
        $form.Cursor = if ($Busy) { [System.Windows.Forms.Cursors]::WaitCursor } else { [System.Windows.Forms.Cursors]::Default }
        $btnAdd.Enabled          = -not $Busy
        $btnRefresh.Enabled      = -not $Busy
        $btnBackup.Enabled       = -not $Busy
        $btnOpenBackup.Enabled   = -not $Busy
        $btnHelp.Enabled         = -not $Busy
        $txtMainFilter.Enabled   = -not $Busy

        if ($Busy) {
            if ($Status) {
                $lblInfo.Text = $Status
                try { $lblInfo.Update() } catch { }
                try { $form.Update() } catch { }
            }
        } else {
            Update-InfoLabel
            try { $lblInfo.Update() } catch { }
        }
    } catch { }
}

function Schedule-Save {
    $script:pendingSave = $true
    if ($script:saveDebounceTimer) {
        try { $script:saveDebounceTimer.Stop() } catch { }
    } else {
        $script:saveDebounceTimer = New-Object System.Windows.Forms.Timer
        $script:saveDebounceTimer.Interval = 400
        $script:saveDebounceTimer.Add_Tick({
            $script:saveDebounceTimer.Stop()
            if ($script:pendingSave) {
                $script:pendingSave = $false
                Save-State
            }
        })
    }
    $script:saveDebounceTimer.Start()
}

# Profiles are keyed by source export path, not file name alone. Two exports
# at different paths cannot contaminate one another's manual EXEs or checkboxes.
# Never copy state from a different source on first open.
# Folder provenance is separate from active scan roots. Removing a root must
# stop scanning it, but preserve evidence that our manager originally added it.
# No metadata is ever added to the AmneziaVPN export.
function Remember-ManagedFolder([string]$folder, $appPaths) {
    if ([string]::IsNullOrWhiteSpace($folder)) { return }
    $folder = Normalize-FullPath $folder
    $item = $null
    foreach ($candidate in @($script:folderProvenance)) {
        if ([string]::Equals([string]$candidate.Path, $folder, [System.StringComparison]::OrdinalIgnoreCase)) {
            $item = $candidate; break
        }
    }
    if ($null -eq $item) {
        $item = [PSCustomObject]@{ Path=$folder; Apps=@(); DisabledApps=@() }
        $script:folderProvenance += $item
    }
    $apps = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($app in @($item.Apps) + @($appPaths)) {
        if ([string]::IsNullOrWhiteSpace([string]$app)) { continue }
        $exe = [string]$app
        if ($exe.EndsWith('.exe', [System.StringComparison]::OrdinalIgnoreCase) -and
            (Test-PathWithinFolder $exe $folder)) { [void]$apps.Add((Normalize-FullPath $exe)) }
    }
    $item.Apps = @($apps | Select-Object -First 5000)
    # Persist explicit unchecked states independently of the currently active
    # source backup. Re-exporting from Amnezia removes disabled paths from the
    # source, so the next profile cannot infer those states from its own JSON.
    if (-not $item.PSObject.Properties['DisabledApps']) {
        $item | Add-Member NoteProperty DisabledApps @() -Force
    }
    $disabled = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($path in @($item.DisabledApps)) {
        if (-not [string]::IsNullOrWhiteSpace([string]$path) -and
            (Test-PathWithinFolder ([string]$path) $folder)) {
            [void]$disabled.Add((Normalize-FullPath ([string]$path)))
        }
    }
    # Update only known selections. An EXE absent from the new export is not
    # evidence it was re-enabled; do not drop its remembered false value.
    foreach ($p in @($script:selected.PSObject.Properties)) {
        if (-not (Test-PathWithinFolder ([string]$p.Name) $folder)) { continue }
        $key = Normalize-FullPath ([string]$p.Name)
        if ([bool]$p.Value) { [void]$disabled.Remove($key) }
        else { [void]$disabled.Add($key) }
    }
    $item.DisabledApps = @($disabled | Select-Object -First 5000)
    $script:folderProvenance = @($script:folderProvenance | Select-Object -Last 100)
}
function Remember-CurrentFolders {
    foreach ($folder in @($script:folders)) {
        $current = @($script:selected.PSObject.Properties | Where-Object {
            Test-PathWithinFolder ([string]$_.Name) $folder
        } | ForEach-Object { [string]$_.Name })
        Remember-ManagedFolder $folder $current
    }
}
function Restore-FoldersFromProvenance($stats) {
    if (@($script:folders).Count -gt 0) { return $false }
    $sourceExe = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($a in @($stats.Apps)) {
        if ($a -and $a.appPath -and ([string]$a.appPath).EndsWith('.exe', [System.StringComparison]::OrdinalIgnoreCase)) {
            [void]$sourceExe.Add((Get-PathKey ([string]$a.appPath)))
        }
    }
    if ($sourceExe.Count -eq 0) { return $false }
    $restored = New-Object 'System.Collections.Generic.List[string]'
    foreach ($record in @($script:folderProvenance)) {
        if ($null -eq $record -or [string]::IsNullOrWhiteSpace([string]$record.Path)) { continue }
        $match = 0
        foreach ($app in @($record.Apps)) {
            if ($sourceExe.Contains((Get-PathKey ([string]$app)))) { $match++ }
        }
        if ($match -eq 0) { continue }
        if (-not (Test-Path -LiteralPath ([string]$record.Path) -PathType Container)) { continue }
        [void]$restored.Add([string]$record.Path)
        Write-Log "История каталога совпала с экспортом: $($record.Path); EXE: $match"
    }
    if ($restored.Count -eq 0) { return $false }
    # Apply persisted false values before the background scan. The scan only
    # adds paths that have no selection property, so these stay unchecked.
    $restoredUnchecked = 0
    foreach ($record in @($script:folderProvenance)) {
        if ($null -eq $record -or -not $record.PSObject.Properties['DisabledApps']) { continue }
        if (-not (@($restored | Where-Object {
            [string]::Equals([string]$_, [string]$record.Path, [System.StringComparison]::OrdinalIgnoreCase)
        }).Count -gt 0)) { continue }
        foreach ($app in @($record.DisabledApps)) {
            if ([string]::IsNullOrWhiteSpace([string]$app) -or
                -not (Test-PathWithinFolder ([string]$app) ([string]$record.Path))) { continue }
            if (-not (Test-Path -LiteralPath ([string]$app) -PathType Leaf)) { continue }
            $key = Get-PathKey ([string]$app)
            if (-not $script:selected.PSObject.Properties[$key]) {
                $script:selected | Add-Member NoteProperty $key $false -Force
                $restoredUnchecked++
            }
        }
    }
    Write-Log "Из истории восстановлено снятых галочек EXE: $restoredUnchecked"
    $script:folders = @(Normalize-FolderList $restored.ToArray())
    $script:restoredScanFolders = (@($script:folders).Count -gt 0)
    if ($script:restoredScanFolders) {
        Invalidate-ExeCache
        Write-Log "Каталоги восстановлены по истории управляемых EXE: $(@($script:folders).Count)"
    }
    return $script:restoredScanFolders
}

function Get-BackupProfile([string]$key) {
    foreach ($entryProfile in @($script:backupProfiles)) {
        if ([string]::Equals([string]$entryProfile.Path, $key, [System.StringComparison]::OrdinalIgnoreCase)) { return $entryProfile }
    }
    return $null
}
function Copy-Selection($source) {
    $copy = [PSCustomObject]@{}
    if ($null -ne $source) {
        foreach ($p in @($source.PSObject.Properties)) {
            $copy | Add-Member -MemberType NoteProperty -Name $p.Name -Value ([bool]$p.Value) -Force
        }
    }
    return $copy
}
function Store-ActiveBackupProfile {
    if (-not $script:activeProfileKey) { return }
    $entryProfile = Get-BackupProfile $script:activeProfileKey
    if ($null -eq $entryProfile) {
        $entryProfile = [PSCustomObject]@{ Path=$script:activeProfileKey; Selected=([PSCustomObject]@{}); ManualApps=@(); ManagedApps=@(); DeletedApps=@(); ScanFolders=@(); LastUsed='' }
        $script:backupProfiles += $entryProfile
    }
    Remember-CurrentFolders
    $entryProfile.Selected = Copy-Selection $script:selected
    $entryProfile.ManualApps = @($script:manualApps | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    $entryProfile.ManagedApps = @($script:managedApps)
    $entryProfile.DeletedApps = @($script:deletedApps)
    # Only folders selected through Folder Manager are recorded here.
    # Save even an empty list: deleting a folder must cancel its restoration.
    $currentScanFolders = @(Normalize-FolderList $script:folders)
    if ($entryProfile.PSObject.Properties['ScanFolders']) {
        $entryProfile.ScanFolders = $currentScanFolders
    } else {
        $entryProfile | Add-Member -MemberType NoteProperty -Name ScanFolders -Value $currentScanFolders -Force
    }
    $entryProfile.LastUsed = (Get-Date).ToString('o')
    # Bound the on-disk profile history. Keep the active profile; remove oldest.
    $script:backupProfiles = @($script:backupProfiles | Sort-Object LastUsed -Descending | Select-Object -First 20)
}
function Switch-BackupProfile([string]$path) {
    $key = Get-PathKey $path
    if ([string]::IsNullOrWhiteSpace($key)) { throw 'Не задан путь исходного backup.' }
    if ($script:activeProfileKey -eq $key) { return }
    Store-ActiveBackupProfile
    $entryProfile = Get-BackupProfile $key
    if ($null -eq $entryProfile -and $script:legacyBackupKey -eq $key -and $script:legacyProfile) {
        # One-time migration of old folders.json data, only for its original backup.
        $entryProfile = $script:legacyProfile
        $script:legacyBackupKey = ''
    }
    $script:selected = if ($entryProfile) { Copy-Selection $entryProfile.Selected } else { [PSCustomObject]@{} }
    $script:manualApps = if ($entryProfile) { @($entryProfile.ManualApps | Where-Object { $_ }) } else { @() }
    $script:managedApps = if ($entryProfile) { @($entryProfile.ManagedApps | Where-Object { $_ }) } else { @() }
    $script:deletedApps = if ($entryProfile) { @($entryProfile.DeletedApps | Where-Object { $_ }) } else { @() }
    $script:activeProfileKey = $key
    $script:restoredScanFolders = $false
    # The scan list remains shared across backups. Restore a known scan root
    # from this source's manager profile ONLY when that shared list is empty.
    # Paths from Amnezia's EXE records must never become scan roots by guesswork.
    if (@($script:folders).Count -eq 0 -and $entryProfile -and
        $entryProfile.PSObject.Properties['ScanFolders']) {
        $existingRoots = @($entryProfile.ScanFolders | Where-Object {
            -not [string]::IsNullOrWhiteSpace([string]$_) -and
            (Test-Path -LiteralPath ([string]$_) -PathType Container)
        })
        if ($existingRoots.Count -gt 0) {
            $script:folders = @(Normalize-FolderList $existingRoots)
            $script:restoredScanFolders = (@($script:folders).Count -gt 0)
            if ($script:restoredScanFolders) {
                Invalidate-ExeCache
                Write-Log "Восстановлены каталоги из профиля backup: $(@($script:folders).Count)"
            }
        }
    }
    # Folder list is shared, but its scanned EXEs are reconstructed per backup.
    # Reuse the existing scan cache; do not block the UI on disk traversal here.
    foreach ($folder in @($script:folders)) {
        if ($script:scanState[(Get-PathKey $folder)] -ne 'OK') { continue }
        foreach ($fi in @(Get-CachedExeFiles -folder $folder)) {
            $exeKey = Get-PathKey $fi.FullName
            if (-not $script:selected.PSObject.Properties[$exeKey]) {
                $script:selected | Add-Member NoteProperty $exeKey $true -Force
            }
        }
    }
    Write-Log "Backup profile switched: $key; manual=$(@($script:manualApps).Count)"
}

function Save-State {
    Store-ActiveBackupProfile
    $cfg.BackupProfiles = @($script:backupProfiles)
    $cfg.FolderProvenance = @($script:folderProvenance)
    $cfg.Folders    = @($script:folders)
    $cfg.ExcludedFolders = @($script:excludedFolders)
    $cfg.ManagedApps = @($script:managedApps)
    $cfg.ManualApps = @($script:manualApps | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    $cfg.DeletedApps = @($script:deletedApps | Select-Object -Unique)
    $cfg.Selected   = $script:selected
    $cfg.LastBackup = $script:lastBackup
    $cfg.HideIntro  = $script:hideIntro
    if (-not (Save-Config $cfg)) {
        Log "ОШИБКА: не удалось сохранить конфигурацию: $ConfigPath"
        [void][System.Windows.Forms.MessageBox]::Show(
            "Не удалось сохранить список папок и отметки!`nПуть: $ConfigPath`nПроверьте журнал amnezia-fm.log.",
            'Ошибка сохранения', [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error)
        return $false
    }
    return $true
}

function Clean-StaleSelected {
    $toRemove = New-Object 'System.Collections.Generic.List[string]'
    $currentKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($folder in $script:folders) {
        foreach ($fi in @(Get-CachedExeFiles -folder $folder)) { [void]$currentKeys.Add((Get-PathKey $fi.FullName)) }
    }
    foreach ($p in @($script:selected.PSObject.Properties)) {
        if (Test-IsExcluded $p.Name) { continue } # Keep selection for a reversible exclusion.
        if (-not (Test-PathInAnyConfiguredFolder $p.Name $script:folders)) {
            if (@($script:manualApps | Where-Object { (Get-PathKey $_) -eq (Get-PathKey $p.Name) }).Count -eq 0) { [void]$toRemove.Add($p.Name) }
            continue
        }
        $owner = @($script:folders | Where-Object { Test-PathWithinFolder $p.Name $_ } | Select-Object -First 1)
        if ($owner.Count -eq 0) { continue }
        # Do not delete data when the root or any subtree scan was incomplete.
        if ($script:scanState[(Get-PathKey $owner[0])] -ne 'OK') {
            if (-not (Test-Path -LiteralPath $p.Name -PathType Leaf)) { [void]$toRemove.Add($p.Name) }
            continue
        }
        if (-not $currentKeys.Contains((Get-PathKey $p.Name))) { [void]$toRemove.Add($p.Name) }
    }
    foreach ($key in $toRemove) { $script:selected.PSObject.Properties.Remove($key) }
    $missingManual = Clean-MissingManualApps
    return ($toRemove.Count + $missingManual)
}


function Get-FilterText {
    if ($script:filterIsPlaceholder) { return "" }
    return [string]$txtMainFilter.Text
}

function Rebuild-Tree {
    param([string]$filterText = $null)



    if ($null -eq $filterText) {
        $filterText = Get-FilterText
    }

    # Preserve the expansion state across all nesting levels, not just root nodes.
    $expanded = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $expandQueue = New-Object 'System.Collections.Generic.Queue[System.Windows.Forms.TreeNode]'
    foreach ($rootNode in $tree.Nodes) { $expandQueue.Enqueue($rootNode) }
    while ($expandQueue.Count -gt 0) {
        $oldNode = $expandQueue.Dequeue()
        if ($oldNode.IsExpanded -and $oldNode.Tag -and $oldNode.Tag.Path) {
            [void]$expanded.Add((Get-PathKey $oldNode.Tag.Path))
        }
        foreach ($childNode in $oldNode.Nodes) { $expandQueue.Enqueue($childNode) }
    }

    $wasUpdating = $script:treeUpdating
    $script:treeUpdating = $true
    $tree.BeginUpdate()
    try {
        $tree.Nodes.Clear()

        $totalFolders = $script:folders.Count
        $idx = 0
        $filter = if ([string]::IsNullOrWhiteSpace($filterText)) { $null } else { $filterText.Trim().ToLowerInvariant() }

        # Сначала сканируем все папки (с прогрессом), потом быстро строим дерево
        $scanResults = @{}
        foreach ($folder in $script:folders) {
            $idx++
            Set-UiBusy $true ("Сканирование $idx/$totalFolders : $folder ...")
            $progressAction = {
                param($scanned, $found)
                try {
                    $lblInfo.Text = "Сканирование $idx/$totalFolders : $folder  (папок: $scanned, exe: $found)"
                    $lblInfo.Update()
                } catch { }
            }
            $scanResults[$folder] = @(Get-CachedExeFiles -folder $folder -onProgress $progressAction)
        }

        Set-UiBusy $true "Построение дерева..."
        foreach ($folder in $script:folders) {
            $exeList = @($scanResults[$folder])
            $missing = Folder-Missing $folder

            $exeCount = 0
            $checkedCount = 0
            $visibleCount = 0
            $folderNode = New-Object System.Windows.Forms.TreeNode($folder)
            $folderNode.Tag = @{ Type = "Folder"; Path = $folder }

            $dirNodes = @{}
            $dirNodes[(Get-PathKey $folder)] = $folderNode
            $filtered = @($exeList | Where-Object {
                if (-not $filter) { return $true }
                $relPath = $_.FullName.Substring($folder.Length).TrimStart('\')
                return ($relPath.ToLowerInvariant().Contains($filter))
            })
            foreach ($fi in $filtered) {
                $exe = $fi.FullName
                $key = Get-PathKey $exe
                $directory = Split-Path -Parent $exe
                $segments = @()
                $walk = $directory
                while ($walk -and -not [string]::Equals($walk,$folder,[System.StringComparison]::OrdinalIgnoreCase)) {
                    $segments = @($walk) + $segments
                    $parentWalk = Split-Path -Parent $walk
                    if ($walk -eq $parentWalk) { break }
                    $walk = $parentWalk
                }
                $parentNode = $folderNode
                foreach ($dirPath in $segments) {
                    $dk = Get-PathKey $dirPath
                    if (-not $dirNodes.ContainsKey($dk)) {
                        $dirNode = New-Object System.Windows.Forms.TreeNode((Split-Path $dirPath -Leaf))
                        $dirNode.Tag = @{ Type='Subfolder'; Path=$dirPath }
                        [void]$parentNode.Nodes.Add($dirNode)
                        $dirNodes[$dk] = $dirNode
                    }
                    $parentNode = $dirNodes[$dk]
                }
                $line = "$($fi.Name)   [$(Format-Size $fi.Length)]"
                $exeNode = New-Object System.Windows.Forms.TreeNode($line)
                $exeNode.Tag = @{ Type='Exe'; Path=$exe; Key=$key }
                if ($fi.Name -match '^(unins|uninstall|setup|crash(report|handler)|unitycrashhandler)') {
                    $exeNode.Text = '[СЛУЖЕБНЫЙ?] ' + $exeNode.Text
                    $exeNode.ToolTipText = 'Похоже на вспомогательный EXE. Выбор остаётся за вами.'
                }
                $prop = $script:selected.PSObject.Properties[$key]
                $isChecked = if ($prop) { [bool]$prop.Value } else { $true }
                $exeNode.Checked = $isChecked
                [void]$parentNode.Nodes.Add($exeNode)
                $exeCount++; $visibleCount++
                if ($isChecked) { $checkedCount++ }
            }
            foreach ($excluded in @($script:excludedFolders)) {
                if (-not (Test-PathWithinFolder $excluded $folder)) { continue }
                $parentPath = Split-Path -Parent $excluded
                $parentNode = $folderNode
                $walkPaths = @()
                $walk = $parentPath
                while ($walk -and -not [string]::Equals($walk,$folder,[System.StringComparison]::OrdinalIgnoreCase)) {
                    $walkPaths = @($walk) + $walkPaths
                    $pw = Split-Path -Parent $walk
                    if ($pw -eq $walk) { break }
                    $walk = $pw
                }
                foreach ($dirPath in $walkPaths) {
                    $dk = Get-PathKey $dirPath
                    if (-not $dirNodes.ContainsKey($dk)) {
                        $dn = New-Object System.Windows.Forms.TreeNode((Split-Path $dirPath -Leaf))
                        $dn.Tag = @{ Type='Subfolder'; Path=$dirPath }
                        [void]$parentNode.Nodes.Add($dn)
                        $dirNodes[$dk] = $dn
                    }
                    $parentNode = $dirNodes[$dk]
                }
                if (-not $filter -or $excluded.ToLowerInvariant().Contains($filter)) {
                    $excludedNode = New-Object System.Windows.Forms.TreeNode("[ПРОПУСК] " + (Split-Path $excluded -Leaf))
                    $excludedNode.Tag = @{ Type='Excluded'; Path=$excluded }
                    $excludedNode.Checked = $false
                    Set-NodeColor $excludedNode $C.TextMuted
                    [void]$parentNode.Nodes.Add($excludedNode)
                    $visibleCount++
                }
            }


            # Bottom-up counts: each EXE is visited once, instead of scanning all
            # selected paths for every directory (O(nodes + exe) vs O(nodes * exe)).
            $treeCounts = @{}
            $countStack = New-Object 'System.Collections.Generic.Stack[object]'
            $countStack.Push(@($folderNode, $false))
            while ($countStack.Count -gt 0) {
                $frame = $countStack.Pop()
                $item = $frame[0]
                if (-not $frame[1]) {
                    $countStack.Push(@($item, $true))
                    foreach ($child in $item.Nodes) { $countStack.Push(@($child, $false)) }
                    continue
                }
                $total = 0; $on = 0
                if ($item.Tag -and $item.Tag.Type -eq 'Exe') {
                    $total = 1
                    if ($item.Checked) { $on = 1 }
                } else {
                    foreach ($child in $item.Nodes) {
                        $ck = $child
                        if ($treeCounts.ContainsKey($ck)) {
                            $total += $treeCounts[$ck].Total
                            $on += $treeCounts[$ck].On
                        }
                    }
                    if ($item.Tag -and $item.Tag.Type -ne 'Excluded') {
                        $item.Checked = ($total -gt 0 -and $total -eq $on)
                        if ($item -ne $folderNode -and $total -gt 0 -and $on -gt 0 -and $on -lt $total) {
                            $item.Text = '[ЧАСТЬ] ' + $item.Text
                        }
                    }
                }
                $treeCounts[$item] = @{ Total=$total; On=$on }
            }
            # Счётчик EXE в названии узла
            $title = "$folder  ($exeCount)"
            if ($missing) { $title = "(!) $title" }
            $folderNode.Text = $title

            if ($visibleCount -eq 0 -and $filter) { continue }
            $folderNode.Checked = ($exeCount -gt 0 -and $checkedCount -eq $exeCount)
            if ($missing -or $exeCount -eq 0) { Set-NodeColor $folderNode $C.TextMuted }
            if ($script:scanState[(Get-PathKey $folder)] -eq "PARTIAL") { $folderNode.Text = "[ЧАСТИЧНО] " + $folderNode.Text }

            [void]$tree.Nodes.Add($folderNode)

            # Восстановить раскрытие
            $restoreStack = New-Object 'System.Collections.Generic.Stack[System.Windows.Forms.TreeNode]'
            $restoreStack.Push($folderNode)
            while ($restoreStack.Count -gt 0) {
                $restoreNode = $restoreStack.Pop()
                if ($restoreNode.Tag -and $restoreNode.Tag.Path -and
                    $expanded.Contains((Get-PathKey $restoreNode.Tag.Path))) {
                    $restoreNode.Expand()
                }
                foreach ($childNode in $restoreNode.Nodes) { $restoreStack.Push($childNode) }
            }
        }



        # Manual EXEs are first-class entries in the same tree.
        $manualRoot = New-Object System.Windows.Forms.TreeNode('Добавленные вручную')
        $manualRoot.Tag = @{ Type='ManualRoot'; Path='' }
        $manualVisible = 0
        $manualKeysDrawn = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        $deletedManualKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($removedPath in @($script:deletedApps)) { if ($removedPath) { [void]$deletedManualKeys.Add((Get-PathKey $removedPath)) } }
        foreach ($path in @($script:manualApps | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) } | Sort-Object -Unique)) {
            if (Test-PathInAnyConfiguredFolder $path $script:folders) { continue }
            $key = Get-PathKey $path
            if (-not $manualKeysDrawn.Add($key) -or $deletedManualKeys.Contains($key)) { continue }
            if ($filter -and -not $path.ToLowerInvariant().Contains($filter)) { continue }
            $node = New-Object System.Windows.Forms.TreeNode([System.IO.Path]::GetFileName($path))
            $node.Tag = @{ Type='Exe'; Path=$path; Key=$key; Manual=$true }
            $node.ToolTipText = $path
            $prop = $script:selected.PSObject.Properties[$key]
            $node.Checked = [bool]($prop -and $prop.Value)
            [void]$manualRoot.Nodes.Add($node)
            $manualVisible++
        }
        if ($manualVisible -gt 0) {
            $manualRoot.Text = "Добавленные вручную ($manualVisible)"
            [void]$tree.Nodes.Add($manualRoot)
            $manualRoot.Expand()
        }

        Update-InfoLabel
        if ($script:lastBackup -and $script:lastBackup -ne "") {
            $lblLast.Text = "Открыт backup: $($script:lastBackup)"
        } else {
            $lblLast.Text = "Последний использованный backup: (не указан)"
        }
    } finally {
        $tree.EndUpdate()
        $script:treeUpdating = $wasUpdating
        Set-UiBusy $false $null
    }
}

function Import-ManualApps($stats) {
    $known = @{}
    foreach ($p in @($script:manualApps)) { $known[(Get-PathKey $p)] = $true }
    $deleted = @{}
    foreach ($p in @($script:deletedApps)) { $deleted[(Get-PathKey $p)] = $true }
    # Entries once owned by a scanned folder never silently become manual
    # merely because their folder was removed from the scan list.
    $previouslyManaged = @{}
    foreach ($p in @($script:managedApps)) { $previouslyManaged[(Get-PathKey $p)] = $true }
    $added = 0
    foreach ($entry in @($stats.Apps)) {
        if (-not $entry -or -not $entry.appPath) { continue }
        $path = Normalize-FullPath ([string]$entry.appPath)
        if (-not $path.EndsWith('.exe',[System.StringComparison]::OrdinalIgnoreCase)) { continue }
        $key = Get-PathKey $path
        if (-not $key -or (Test-PathInAnyConfiguredFolder $path $script:folders)) { continue }
        if ($deleted.ContainsKey($key) -or $previouslyManaged.ContainsKey($key)) { continue }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        if (-not $known.ContainsKey($key)) {
            $script:manualApps += $path
            $known[$key] = $true
            $added++
        }
        if (-not $script:selected.PSObject.Properties[$key]) {
            $script:selected | Add-Member -MemberType NoteProperty -Name $key -Value $true
        }
    }
    return $added
}

# Construct the manual EXE collection deterministically from the current
# source export and the current profile. Do not depend on mutations performed
# while importing or rebuilding WinForms nodes.
function Resolve-ManualAppsFromBackup($stats) {
    $unique = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    $resolved = New-Object 'System.Collections.Generic.List[string]'
    $blocked = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($p in @($script:managedApps) + @($script:deletedApps)) {
        if ($p) { [void]$blocked.Add((Get-PathKey ([string]$p))) }
    }
    $candidates = @($script:manualApps)
    foreach ($entry in @($stats.Apps)) {
        if ($entry -and $entry.appPath) { $candidates += [string]$entry.appPath }
    }
    foreach ($candidate in $candidates) {
        if (-not $candidate) { continue }
        $path = Normalize-FullPath ([string]$candidate)
        if (-not $path -or -not $path.EndsWith('.exe', [System.StringComparison]::OrdinalIgnoreCase)) { continue }
        $key = Get-PathKey $path
        if (-not $key -or $blocked.Contains($key)) { continue }
        if (Test-PathInAnyConfiguredFolder $path $script:folders) { continue }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        if ($unique.Add($key)) {
            [void]$resolved.Add($path)
            if (-not $script:selected.PSObject.Properties[$key]) {
                $script:selected | Add-Member -MemberType NoteProperty -Name $key -Value $true
            }
        }
    }
    # Emit individual non-empty paths only; no unary-comma array wrapper.
    # PowerShell otherwise treats a single empty array as one null element.
    foreach ($resolvedPath in $resolved) { if (-not [string]::IsNullOrWhiteSpace($resolvedPath)) { Write-Output $resolvedPath } }
}

function Clean-MissingManualApps {
    $keep = New-Object 'System.Collections.Generic.List[string]'
    $removed = 0
    foreach ($path in @($script:manualApps)) {
        if ([string]::IsNullOrWhiteSpace([string]$path)) { $removed++; continue }
        if (Test-Path -LiteralPath $path -PathType Leaf) {
            [void]$keep.Add($path)
        } else {
            $key = Get-PathKey $path
            if ($script:selected.PSObject.Properties[$key]) { $script:selected.PSObject.Properties.Remove($key) }
            $removed++
        }
    }
    $script:manualApps = @($keep.ToArray() | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
    return $removed
}

function Compute-BackupStats($backupPath) {
    $j = (Get-Content -LiteralPath $backupPath -Raw -Encoding UTF8) | ConvertFrom-Json
    if ($null -eq $j -or $j -isnot [psobject] -or $j -is [array]) {
        throw "Файл не содержит ожидаемый JSON-объект AmneziaVPN."
    }
    $prop = $j.PSObject.Properties["Conf/ExceptApps"]
    if (-not $prop -or $null -eq $prop.Value) {
        throw "В исходном backup отсутствует поле Conf/ExceptApps. Выберите актуальный экспорт AmneziaVPN с поддерживаемой структурой."
    }
    if ($prop.Value -isnot [array]) {
        throw "Поле Conf/ExceptApps должно быть массивом."
    }
    $apps = @($prop.Value)

    $existing = @{}
    foreach ($a in $apps) {
        if ($a -and $a.appPath) { $existing[(Get-PathKey $a.appPath.ToString())] = $true }
    }

    $newCount = 0; $alreadyCount = 0; $skipCount = 0; $missingCount = 0
    foreach ($p in $script:selected.PSObject.Properties) {
        if (-not $p.Value) { $skipCount++; continue }
        if (-not (Test-Path -LiteralPath $p.Name)) { $missingCount++; continue }
        if ($existing.ContainsKey((Get-PathKey $p.Name))) { $alreadyCount++ } else { $newCount++ }
    }
    return @{
        InBackup = $apps.Count
        New      = $newCount
        Already  = $alreadyCount
        Skipped  = $skipCount
        Missing  = $missingCount
        Existing = $existing
        Apps     = $apps
        Json     = $j
    }
}

function Sync-FolderDatabase([string]$folder) {
    $current = @{}
    foreach ($exe in @(Get-CachedExeFiles -folder $folder)) {
        $current[(Get-PathKey $exe.FullName)] = $exe
    }

    $removed = 0
    $added = 0

    $canPrune = ($script:scanState[(Get-PathKey $folder)] -eq "OK")
    $keys = @($script:selected.PSObject.Properties.Name)
    foreach ($key in $keys) {
        if (-not (Test-PathWithinFolder $key $folder)) { continue }
        if ($canPrune -and -not $current.ContainsKey((Get-PathKey $key))) {
            $script:selected.PSObject.Properties.Remove($key)
            $removed++
        }
    }

    # A partial scan is not authoritative: never mutate selected paths for that root.
    if (-not $canPrune) {
        Write-Log "Sync: partial scan for $folder, keeping the prior selection unchanged"
        return @{ Added = 0; Removed = 0; Current = $current.Count }
    }

    foreach ($key in $current.Keys) {
        if (-not $script:selected.PSObject.Properties[$key]) {
            $script:selected | Add-Member -MemberType NoteProperty -Name $key -Value $true -Force
            $added++
        }
    }

    return @{ Added = $added; Removed = $removed; Current = $current.Count }
}

function Add-OneFolder($folder) {
    if ($script:scanWork) {
        [void][System.Windows.Forms.MessageBox]::Show('Дождитесь окончания текущего сканирования.')
        return
    }
    $folder = Normalize-FullPath $folder

    foreach ($existingFolder in @($script:folders)) {
        if (Test-PathWithinFolder $folder $existingFolder) {
            [void][System.Windows.Forms.MessageBox]::Show(
                "Эта папка уже покрывается другой добавленной папкой:`n`n$existingFolder",
                "Папка уже покрыта")
            return
        }
        if (Test-PathWithinFolder $existingFolder $folder) {
            [void][System.Windows.Forms.MessageBox]::Show(
                "Нельзя добавить вложенную папку:`n`n$folder`n`nОна уже находится внутри:`n$existingFolder",
                "Вложенная папка")
            return
        }
    }

    if ($script:folders -contains $folder) {
        [void][System.Windows.Forms.MessageBox]::Show(
            "Эта папка уже добавлена.", "Папка уже есть",
            [System.Windows.Forms.MessageBoxButtons]::OK)
        return
    }

    # Do not scan synchronously while a directory is added. The background
    # refresh will fill its EXEs and update the tree on the UI thread.
    $script:folders += $folder
    Invalidate-ExeCache
    Save-State
    Log "Добавлена папка: $folder (сканирование в фоне)"
    Start-BackgroundRefresh
}

function Do-UpdateOnly {
    Set-UiBusy $true "Обновление базы..."
    try {
        Invalidate-ExeCache
        $newCount = 0
        foreach ($folder in $script:folders) {
            if (-not (Test-Path -LiteralPath $folder)) { continue }
            $exeList = @(Get-CachedExeFiles -folder $folder)
            if ($script:scanState[(Get-PathKey $folder)] -ne 'OK') {
                Write-Log "Update: incomplete scan for $folder; no new paths imported from this folder"
                continue
            }
            foreach ($fi in $exeList) {
                $key = $fi.FullName.ToLowerInvariant()
                if (-not $script:selected.PSObject.Properties[$key]) {
                    $script:selected | Add-Member -MemberType NoteProperty -Name $key -Value $true -Force
                    $newCount++
                }
                $script:deletedApps = @($script:deletedApps | Where-Object { (Get-PathKey $_) -ne (Get-PathKey $key) })
            }
        }
        $removedCount = Clean-StaleSelected
        Save-State
    } finally {
        Set-UiBusy $false $null
    }
    Rebuild-Tree
    Write-OperationHistory 'SCAN' ("Added=$newCount Removed=$removedCount")
    Log "Обновление: новых EXE — $newCount; удалено отсутствующих — $removedCount"
    return @{ New = $newCount; Removed = $removedCount }
}


function Get-BackupPlan($stats) {
    # A single global namespace for EXE paths. Ownership of every EXE belongs
    # to this utility; unrecognized non-EXE backup records are preserved.
    $previouslyManaged = @{}
    foreach ($path in @($script:managedApps)) { if ($path) { $previouslyManaged[(Get-PathKey $path)] = $true } }
    $manual = @{}
    foreach ($path in @($script:manualApps)) { if ($path) { $manual[(Get-PathKey $path)] = $true } }
    $deletedKeys = @{}
    foreach ($path in @($script:deletedApps)) { if ($path) { $deletedKeys[(Get-PathKey $path)] = $true } }
    $removed = New-Object 'System.Collections.Generic.List[string]'
    $adopted = New-Object 'System.Collections.Generic.List[string]'
    $duplicates = New-Object 'System.Collections.Generic.List[string]'
    $kept = New-Object 'System.Collections.Generic.List[object]'
    $reasons = @{}
    $seen = @{}
    $ownedKeys = @{}
    $externalCount = 0
    $selectedKeys = @{}
    foreach ($p in $script:selected.PSObject.Properties) { $selectedKeys[(Get-PathKey $p.Name)] = $p }
    foreach ($app in @($stats.Apps)) {
        if (-not $app -or [string]::IsNullOrWhiteSpace([string]$app.appPath)) {
            # Keep opaque non-EXE records, but never manufacture an EXE from a blank path.
            if ($null -ne $app) { [void]$kept.Add($app) }
            continue
        }
        $originalPath = [string]$app.appPath
        $path = Normalize-FullPath $originalPath
        if (-not $path.EndsWith('.exe',[System.StringComparison]::OrdinalIgnoreCase)) {
            [void]$kept.Add($app)
            continue
        }
        $key = Get-PathKey $path
        $ownedKeys[$key] = $true
        $inside = Test-PathInAnyConfiguredFolder $path $script:folders
        $sel = $selectedKeys[$key]
        $reason = ''
        # A deliberately deleted entry must not reappear from an old export.
        if ($deletedKeys.ContainsKey($key)) {
            if ($previouslyManaged.ContainsKey($key) -and -not $inside) { $reason = 'Папка удалена из отслеживания' }
            else { $reason = 'Удалено пользователем' }
        }
        elseif (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $reason = 'Файл отсутствует на диске' }
        elseif ($inside -and (Test-IsExcluded $path)) { $reason = 'Папка исключена' }
        elseif (-not $inside -and $previouslyManaged.ContainsKey($key) -and -not $manual.ContainsKey($key)) { $reason = 'Папка удалена из отслеживания' }
        elseif ($null -ne $sel -and -not [bool]$sel.Value) { $reason = 'Снята галочка' }
        elseif ($seen.ContainsKey($key)) { $reason = 'Дубликат EXE'; [void]$duplicates.Add($path) }
        if ($reason) {
            [void]$removed.Add($path)
            $reasons[$key] = $reason
            continue
        }
        if (-not $inside) { $externalCount++ }
        if ($inside -and -not $previouslyManaged.ContainsKey($key)) { [void]$adopted.Add($path) }
        [void]$kept.Add($app)
        $seen[$key] = $true
    }
    $adds = New-Object 'System.Collections.Generic.List[string]'
    foreach ($p in $script:selected.PSObject.Properties) {
        if (-not [bool]$p.Value) { continue }
        $path = [string]$p.Name
        $key = Get-PathKey $path
        if ($deletedKeys.ContainsKey($key) -or $seen.ContainsKey($key)) { continue }
        $inside = Test-PathInAnyConfiguredFolder $path $script:folders
        if ($inside -and (Test-IsExcluded $path)) { continue }
        if (-not $inside -and -not $manual.ContainsKey($key)) { continue }
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $ownedKeys[$key] = $true
        [void]$adds.Add($path)
        $seen[$key] = $true
        if (-not $inside) { $externalCount++ }
    }
    return @{
        Add=@($adds.ToArray()); Remove=@($removed.ToArray());
        RemoveReasons=$reasons; Keep=@($kept.ToArray());
        Adopt=@($adopted.ToArray()); Duplicates=@($duplicates.ToArray());
        OwnedKeys=$ownedKeys; ManualCount=$externalCount;
        TotalExe=$seen.Count
    }
}

function Show-BackupPreview($backup, $plan, [int]$warningCount) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Подтверждение обновления AmneziaVPN'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = [System.Drawing.Size]::new((Scaled 930),(Scaled 640))
    $dlg.MinimumSize = [System.Drawing.Size]::new((Scaled 650),(Scaled 420))
    $dlg.BackColor = $C.Bg
    $dlg.ForeColor = $C.Text
    $dlg.Font = New-UiFont 9
    $dlg.FormBorderStyle = 'Sizable'
    $dlg.MaximizeBox = $true

    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = 'Fill'
    $layout.Padding = New-Object System.Windows.Forms.Padding((Scaled 14))
    $layout.ColumnCount = 1
    $layout.RowCount = 3
    [void]$layout.RowStyles.Add(([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Absolute,(Scaled 82))))
    [void]$layout.RowStyles.Add(([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Percent,100)))
    [void]$layout.RowStyles.Add(([System.Windows.Forms.RowStyle]::new([System.Windows.Forms.SizeType]::Absolute,(Scaled 55))))
    $dlg.Controls.Add($layout)

    $summary = New-Object System.Windows.Forms.Label
    $summary.Dock = 'Fill'
    $summary.ForeColor = $C.Text
    $summary.AutoEllipsis = $true
    $summary.Font = New-UiFont 9
    $summary.Text = "Добавить: $($plan.Add.Count)     Удалить: $($plan.Remove.Count)     Останется ручных EXE: $($plan.ManualCount)`nПринято под управление: $($plan.Adopt.Count)     Удалено дублей: $($plan.Duplicates.Count)`nПапок с ошибками: $warningCount (их записи защищены)`nИсходный файл: $backup`nРучные EXE также управляются утилитой; дубликаты удаляются во всём backup."
    $layout.Controls.Add($summary,0,0)

    $list = New-Object System.Windows.Forms.ListView
    $list.Dock = 'Fill'
    $list.View = 'Details'
    $list.FullRowSelect = $true
    $list.GridLines = $false
    $list.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $list.Font = New-UiFont 9
    $list.HideSelection = $false
    $list.BackColor = $C.Panel
    $list.ForeColor = $C.Text
    [void]$list.Columns.Add('Действие',(Scaled 125))
    [void]$list.Columns.Add('EXE',(Scaled 255))
    [void]$list.Columns.Add('Причина',(Scaled 180))
    [void]$list.Columns.Add('Папка',(Scaled 500))
    $list.ShowItemToolTips = $true
    # One unified preview: retained, adopted, added and removed EXEs are
    # visible without requiring a checkbox or toggling modes.
    $list.BeginUpdate()
    try {
        $previewKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        $adoptKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($p in @($plan.Adopt)) { if ($p) { [void]$adoptKeys.Add((Get-PathKey ([string]$p))) } }
        foreach ($app in @($plan.Keep)) {
            if (-not $app -or [string]::IsNullOrWhiteSpace([string]$app.appPath)) { continue }
            $path = [string]$app.appPath
            if (-not $path.EndsWith('.exe',[System.StringComparison]::OrdinalIgnoreCase)) { continue }
            $key = Get-PathKey $path
            if (-not $key -or -not $previewKeys.Add($key)) { continue }
            $isAdopt = $adoptKeys.Contains($key)
            $action = if ($isAdopt) { 'Принять' } else { 'Останется' }
            $reason = if ($isAdopt) { 'Передаётся под управление' } else { 'Из исходного backup' }
            $entry = New-Object System.Windows.Forms.ListViewItem($action)
            [void]$entry.SubItems.Add([System.IO.Path]::GetFileName($path))
            [void]$entry.SubItems.Add($reason)
            [void]$entry.SubItems.Add([System.IO.Path]::GetDirectoryName($path))
            $entry.ToolTipText = $path
            if ($isAdopt) { $entry.ForeColor = $C.TextGreen }
            [void]$list.Items.Add($entry)
        }
        foreach ($path in @($plan.Add)) {
            if ([string]::IsNullOrWhiteSpace([string]$path)) { continue }
            $key = Get-PathKey $path
            if (-not $key -or -not $previewKeys.Add($key)) { continue }
            $entry = New-Object System.Windows.Forms.ListViewItem('Добавить')
            [void]$entry.SubItems.Add([System.IO.Path]::GetFileName($path))
            [void]$entry.SubItems.Add('Выбран в Folder Manager')
            [void]$entry.SubItems.Add([System.IO.Path]::GetDirectoryName($path))
            $entry.ToolTipText = $path
            $entry.ForeColor = $C.TextGreen
            [void]$list.Items.Add($entry)
        }
        foreach ($path in @($plan.Remove)) {
            if ([string]::IsNullOrWhiteSpace([string]$path)) { continue }
            $key = Get-PathKey $path
            $reason = $plan.RemoveReasons[$key]
            if (-not $reason) { $reason = 'Больше не управляется' }
            $entry = New-Object System.Windows.Forms.ListViewItem('Удалить')
            [void]$entry.SubItems.Add([System.IO.Path]::GetFileName($path))
            [void]$entry.SubItems.Add($reason)
            [void]$entry.SubItems.Add([System.IO.Path]::GetDirectoryName($path))
            $entry.ToolTipText = "$path`n$reason"
            $entry.ForeColor = $C.Danger
            [void]$list.Items.Add($entry)
        }
        if ($list.Items.Count -eq 0) {
            $emptyItem = New-Object System.Windows.Forms.ListViewItem('Список EXE пуст')
            [void]$emptyItem.SubItems.Add('')
            [void]$emptyItem.SubItems.Add('В итоговом backup не будет исключений приложений')
            [void]$emptyItem.SubItems.Add('')
            $emptyItem.ForeColor = $C.TextMuted
            [void]$list.Items.Add($emptyItem)
        }
    } finally { $list.EndUpdate() }
    $layout.Controls.Add($list,0,1)
    $buttons = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttons.Dock = 'Fill'
    $buttons.FlowDirection = 'RightToLeft'
    $buttons.WrapContents = $false
    $yes = New-Object System.Windows.Forms.Button
    $yes.Text = 'Создать backup'
    $yes.Width = Scaled 150
    $yes.Height = Scaled 34
    Style-PrimaryButton $yes
    $yes.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $no = New-Object System.Windows.Forms.Button
    $no.Text = 'Отмена'
    $no.Width = Scaled 110
    $no.Height = Scaled 34
    Style-SecondaryButton $no
    $no.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    [void]$buttons.Controls.Add($yes)
    [void]$buttons.Controls.Add($no)
    $layout.Controls.Add($buttons,0,2)
    $dlg.AcceptButton = $yes
    $dlg.CancelButton = $no
    try { return ($dlg.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) }
    finally { $dlg.Dispose() }
}

function Select-SourceBackup {
    if ($script:scanWork) {
        $null = [System.Windows.Forms.MessageBox]::Show('Дождитесь окончания сканирования.', 'Сканирование')
        return $false
    }
    $ofd = New-Object System.Windows.Forms.OpenFileDialog
    $ofd.Title = 'Открыть backup AmneziaVPN для просмотра и редактирования'
    $ofd.Filter = 'Amnezia backup (*.backup)|*.backup|Все файлы (*.*)|*.*'
    $ofd.CheckFileExists = $true
    $ofd.Multiselect = $false
    if ($script:sourceBackupPath -and (Test-Path -LiteralPath $script:sourceBackupPath)) {
        $ofd.FileName = $script:sourceBackupPath
    } elseif ($script:lastBackup -and (Test-Path -LiteralPath $script:lastBackup)) {
        $ofd.FileName = $script:lastBackup
    }
    try {
        if ($ofd.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return $false }
        $path = [string]$ofd.FileName
    } finally { $ofd.Dispose() }
    try {
        if (Test-IsGeneratedBackup $path) {
            Log "Отклонён выходной backup как источник: $path"
            Show-GeneratedBackupWarning
            return $false
        }
        $stats = Compute-BackupStats $path
    } catch {
        Log "Ошибка чтения backup: $_"
        $null = [System.Windows.Forms.MessageBox]::Show("Невозможно открыть backup:`n$($_.Exception.Message)", 'Ошибка backup')
        return $false
    }
    try {
        # Finish changing the working profile before pumping WinForms modal events.
        # In the previous version the message dialog was displayed before rebuilding
        # the tree, and the first profile import sometimes disappeared from the
        # active in-memory state during the nested message loop.
        if ($script:pendingSave -and $script:saveDebounceTimer) {
            $script:saveDebounceTimer.Stop()
            $script:pendingSave = $false
            if (-not (Save-State)) { return $false }
        }
        Switch-BackupProfile $path
        # A new Amnezia export can have a different filename/profile. Match its
        # EXE paths against persistent provenance even after a folder was removed.
        [void](Restore-FoldersFromProvenance $stats)
        $beforeManual = @($script:manualApps).Count
        $newManual = Import-ManualApps $stats
        Log "Профиль после импорта: ручных EXE $(@($script:manualApps).Count); импортировано $newManual"
        $removedManual = Clean-MissingManualApps
        Log "Профиль после проверки файлов: ручных EXE $(@($script:manualApps).Count); отсутствующих $removedManual"
        # Import and cleanup must yield an explicit, deterministic collection.
        # Reconcile from the selected backup before persisting the profile.
        $script:manualApps = @(Resolve-ManualAppsFromBackup $stats | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
        Log "Профиль после согласования с исходным backup: ручных EXE $(@($script:manualApps).Count)"
        $script:sourceBackupPath = $path
        $script:lastBackup = $path

        # Capture the fully imported profile, including unchecked entries.
        # Profile data is always distinct from the source backup JSON.
        $expectedManual = @($script:manualApps)
        $expectedSelected = Copy-Selection $script:selected
        $expectedManaged = @($script:managedApps)
        $expectedDeleted = @($script:deletedApps)
        if (-not (Save-State)) { return $false }
        Log "Профиль после Save-State: ручных EXE $(@($script:manualApps).Count)"

        # Restore the prepared state if a config/UI callback changed it during
        # persistence; never show a successful import with an empty working tree.
        if (@($script:manualApps).Count -ne $expectedManual.Count) {
            Log "Предупреждение: состояние профиля изменилось при сохранении; восстановлено из снимка."
            $script:manualApps = @($expectedManual)
            $script:selected = Copy-Selection $expectedSelected
            $script:managedApps = @($expectedManaged)
            $script:deletedApps = @($expectedDeleted)
            if (-not (Save-State)) { return $false }
        }
        Rebuild-Tree
        $tree.Invalidate($true)
        $tree.Update()
        Log "Открыт backup для редактирования: $path; ручных EXE добавлено: $newManual; отсутствующих удалено: $removedManual"
        Log "Дерево обновлено после открытия backup: ручных EXE $(@($script:manualApps).Count), узлов $($tree.Nodes.Count)"
        if ($script:restoredScanFolders) {
            $script:restoredScanFolders = $false
            # Use the existing nonblocking scanner. No modal questions;
            # the tree will refresh on completion, exactly like a manual add.
            Start-BackgroundRefresh
        }
        if ($expectedManual.Count -gt 0 -and @($script:manualApps).Count -eq 0) {
            throw 'После загрузки backup потерян список ручных EXE; операция остановлена.'
        }
        $null = [System.Windows.Forms.MessageBox]::Show(
            "Backup открыт для редактирования.`n`nЗаписей EXE в исходном backup: $(@($stats.Apps | Where-Object { $_ -and $_.appPath -and ([string]$_.appPath).EndsWith('.exe',[System.StringComparison]::OrdinalIgnoreCase) }).Count)`nНовых ручных EXE загружено: $newManual`n`nНастройте галочки в дереве, затем нажмите «Создать backup Amnezia».",
            'Backup открыт', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
        # Modal dialogs can execute queued UI events. Reconcile with the
        # prepared snapshot only if state unexpectedly disappears.
        if ($expectedManual.Count -gt 0 -and @($script:manualApps).Count -eq 0) {
            Log 'Состояние ручных EXE исчезло во время диалога; восстановлено из снимка загрузки.'
            $script:manualApps = @($expectedManual)
            $script:selected = Copy-Selection $expectedSelected
            $script:managedApps = @($expectedManaged)
            $script:deletedApps = @($expectedDeleted)
            Rebuild-Tree
            if (-not (Save-State)) { return $false }
        }
        return $true
    } catch {
        Log "Ошибка загрузки backup: $_"
        $null = [System.Windows.Forms.MessageBox]::Show("Не удалось загрузить записи:`n$($_.Exception.Message)", 'Ошибка backup')
        return $false
    }
}

function Do-CreateBackup {
    # A fresh AmneziaVPN export must be explicitly opened before exporting.
    # Generated outputs are not valid sources.
    if (-not $script:sourceBackupPath -or -not (Test-Path -LiteralPath $script:sourceBackupPath -PathType Leaf)) {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Сначала предоставьте backup, экспортированный из AmneziaVPN.`n`nОткройте AmneziaVPN, экспортируйте актуальную конфигурацию и выберите файл в Folder Manager.`n`nВыбрать backup сейчас?",
            'Необходим backup AmneziaVPN', [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Information)
        if ($answer -ne [System.Windows.Forms.DialogResult]::Yes -or -not (Select-SourceBackup)) { return $false }
    }
    $backup = [string]$script:sourceBackupPath
    try {
        if (Test-IsGeneratedBackup $backup) {
            $script:sourceBackupPath = $null
            Show-GeneratedBackupWarning
            return $false
        }
        $ageHours = ((Get-Date) - (Get-Item -LiteralPath $backup).LastWriteTime).TotalHours
        if ($ageHours -gt 24) {
            $old = [System.Windows.Forms.MessageBox]::Show(
                "Backup изменён более 24 часов назад. Если в AmneziaVPN с тех пор меняли настройки, сначала откройте свежий экспорт.`n`nПродолжить с выбранным файлом?",
                'Давний backup', [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning)
            if ($old -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
        }
        [void](Compute-BackupStats $backup)
    } catch {
        Log "Ошибка проверки исходного backup: $_"
        [void][System.Windows.Forms.MessageBox]::Show("Не удалось прочитать выбранный backup:`n$($_.Exception.Message)", 'Ошибка backup')
        return $false
    }
    $script:pendingBackupPath = $backup
    Log 'Перед созданием backup запускается фоновая проверка каталогов.'
    Start-BackgroundRefresh
    return $true
}

function Complete-CreateBackup([string]$backup) {
    # The async scan has completed and filled a consistent cache and selection.
    # Manual entries in the source backup are imported below.
    Log 'Фоновая проверка завершена; анализируем backup.'
    try {
        $stats = Compute-BackupStats $backup
        $newManual = Import-ManualApps $stats
        $goneManual = Clean-MissingManualApps
        Write-Log "Manual EXE: imported=$newManual missing=$goneManual"
        $plan = Get-BackupPlan $stats
        Log ("План backup: источник EXE {0}, итог EXE {1}, добавить {2}, удалить {3}, ручных в результате {4}" -f @($stats.Apps | Where-Object { $_ -and $_.appPath -and ([string]$_.appPath).EndsWith('.exe',[System.StringComparison]::OrdinalIgnoreCase) }).Count, $plan.TotalExe, @($plan.Add).Count, @($plan.Remove).Count, $plan.ManualCount)
        $warningCount = @($script:scanState.Values | Where-Object { $_ -ne 'OK' }).Count
        # Anomalous removal warning is separate from the normal preview.
        $managedBefore = @($stats.Apps | Where-Object {
            $_ -and $_.appPath -and $plan.OwnedKeys.ContainsKey((Get-PathKey ([string]$_.appPath)))
        }).Count
        if ($managedBefore -ge 10 -and $plan.Remove.Count -gt 0 -and
            ([double]$plan.Remove.Count / [double]$managedBefore) -gt 0.30) {
            $warn = [System.Windows.Forms.MessageBox]::Show(
                "ВНИМАНИЕ: планируется удалить $($plan.Remove.Count) из $managedBefore управляемых записей (более 30%).`n`nПроверьте доступность дисков, папки и снятые галочки.`n`nПродолжить к подробному предпросмотру?",
                'Массовое удаление EXE',
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Warning)
            if ($warn -ne [System.Windows.Forms.DialogResult]::Yes) { return $false }
        }
        if (-not (Show-BackupPreview $backup $plan $warningCount)) {
            Log "Backup отменён в предварительном просмотре"
            return $false
        }

        Set-UiBusy $true "Создание backup..."
        try {
            $j = $stats.Json
            $apps = @($plan.Keep)
            $existing = @{}
            foreach ($app in $apps) {
                if ($app -and $app.appPath) { $existing[(Get-PathKey ([string]$app.appPath))] = $true }
            }
            $added = 0
            $addedPaths = @()
            foreach ($path in $plan.Add) {
                if ($existing.ContainsKey((Get-PathKey $path))) { continue }
                if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { continue }
                $fi = Get-Item -LiteralPath $path -ErrorAction Stop
                $apps += [PSCustomObject]@{ appName=$fi.BaseName; packageName=''; appPath=$fi.FullName }
                $existing[(Get-PathKey $fi.FullName)] = $true
                $added++
                $addedPaths += $fi.FullName
            }
            $removedFromBackup = $plan.Remove.Count


            if (-not $j.PSObject.Properties["Conf/ExceptApps"]) {
                $j | Add-Member -MemberType NoteProperty -Name "Conf/ExceptApps" -Value @()
            }
            $j."Conf/ExceptApps" = @($apps)

            $out = Join-Path $OutDir "Amnezia-UPDATED.backup"
            # Serialize to a separate temporary file, verify, then atomically
            # replace only the output. The explicitly opened source stays untouched.
            $jsonTemp = Join-Path $OutDir ("Amnezia-UPDATED.{0}.tmp" -f [Guid]::NewGuid().ToString('N'))
            $previousBackup = "$out.previous.backup"
            try {
                # Preserve the existing, proven Amnezia backup serialization (UTF-8 BOM).
                $j | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $jsonTemp -Encoding UTF8 -ErrorAction Stop
                $verified = Get-Content -LiteralPath $jsonTemp -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
                if (-not $verified.PSObject.Properties['Conf/ExceptApps'] -or $verified.'Conf/ExceptApps' -isnot [array]) { throw 'Проверка выходного backup не пройдена.' }
                if (@($verified.'Conf/ExceptApps').Count -ne @($apps).Count) { throw 'Проверка количества приложений в backup не пройдена.' }
                $seenManaged = @{}
                foreach ($entry in @($verified.'Conf/ExceptApps')) {
                    if (-not $entry -or -not $entry.appPath) { continue }
                    if (-not (Get-PathKey ([string]$entry.appPath)).EndsWith('.exe',[System.StringComparison]::OrdinalIgnoreCase)) { continue }
                    $key = Get-PathKey ([string]$entry.appPath)
                    if ($seenManaged.ContainsKey($key)) { throw "Дублированный EXE: $($entry.appPath)" }
                    $seenManaged[$key] = $true
                }
                # Preserve non-appPath records (including their metadata).
                $extraSource = @($stats.Apps | Where-Object { -not $_ -or -not $_.appPath })
                $extraResult = @($verified.'Conf/ExceptApps' | Where-Object { -not $_ -or -not $_.appPath })
                if ($extraSource.Count -ne $extraResult.Count) { throw 'Изменилось количество служебных записей AmneziaVPN.' }
                for ($i=0; $i -lt $extraSource.Count; $i++) {
                    if ((ConvertTo-Json -InputObject $extraSource[$i] -Depth 30 -Compress) -cne
                        (ConvertTo-Json -InputObject $extraResult[$i] -Depth 30 -Compress)) {
                        throw "Изменилась служебная запись AmneziaVPN #$($i+1)"
                    }
                }
                if (Test-Path -LiteralPath $out) {
                    # File.Replace updates the destination atomically and saves the old file.
                    # If it fails, retain the previous output instead of risking truncation.
                    [System.IO.File]::Replace($jsonTemp, $out, $previousBackup)
                } else {
                    Move-Item -LiteralPath $jsonTemp -Destination $out -ErrorAction Stop
                }
                Save-PreviousBackup $previousBackup
                Register-GeneratedBackup $out
            } finally {
                if (Test-Path -LiteralPath $jsonTemp) { Remove-Item -LiteralPath $jsonTemp -Force -ErrorAction SilentlyContinue }
            }


            $removedKeys = @{}
            foreach ($path in $plan.Remove) { $removedKeys[(Get-PathKey $path)] = $true }
            $ownedAfter = @($apps | Where-Object { $_ -and $_.appPath -and $plan.OwnedKeys.ContainsKey((Get-PathKey ([string]$_.appPath))) } | ForEach-Object { [string]$_.appPath })
            # Deleted paths must not be resurrected by importing an older backup.
            $forgetReasons = @('Папка удалена из отслеживания', 'Файл отсутствует на диске', 'Папка исключена')
            $deletedNow = @($plan.Remove | Where-Object { $plan.RemoveReasons[(Get-PathKey $_)] -in $forgetReasons })
            $script:deletedApps = @($script:deletedApps + $deletedNow | Select-Object -Unique | Select-Object -Last 5000)
            # A disabled manual EXE is NOT deleted from the manager: it must
            # survive export, refresh, restart and subsequent imports.
            # Only actual absence (or an explicit deletion via the context menu)
            # removes a manual entry. Duplicates are resolved in the backup,
            # not by forgetting the user's saved checkbox state.
            $script:manualApps = @($script:manualApps | Where-Object {
                $manualKey = Get-PathKey $_
                -not ($removedKeys.ContainsKey($manualKey) -and
                      $plan.RemoveReasons[$manualKey] -eq 'Файл отсутствует на диске')
            })
            # Keep historical ownership (including removed folders). Losing it
            # would allow an old Amnezia export to resurrect those EXEs as manual.
            # Only paths owned by scan roots are managed. Previously this code
            # added EVERY exported EXE to ManagedApps; after removing a scan root
            # even genuine manual entries were then suppressed on import.
            $managedFromOutput = @($addedPaths + $ownedAfter | Where-Object {
                $_ -and (Test-PathInAnyConfiguredFolder ([string]$_) $script:folders)
            })
            $script:managedApps = @($script:managedApps + $managedFromOutput |
                Where-Object { $_ } | Sort-Object -Unique)
            # Keep the opened original export as source; never switch to our output.
            $script:lastBackup = $backup
            $script:backupStateSaved = [bool](Save-State)
        } finally {
            Set-UiBusy $false $null
        }

        Rebuild-Tree

        Write-OperationHistory 'EXPORT' ("Added=$added Removed=$removedFromBackup Duplicates=$($plan.Duplicates.Count) Manual=$($plan.ManualCount)")
        Log "Backup создан: $out (добавлено $added, удалено $removedFromBackup)"
        Log "Добавлено новых: $added"
        foreach ($reasonGroup in @($plan.Remove | Group-Object -Property { $plan.RemoveReasons[(Get-PathKey $_)] })) {
            Log "Удаления ($($reasonGroup.Name)): $($reasonGroup.Count)"
        }

        $saveNote = if ($script:backupStateSaved) { 'Конфигурация сохранена.' } else { 'ВНИМАНИЕ: backup создан, но настройки не сохранились. Проверьте журнал.' }
        $msg = @"
Готово!

Отмечено приложений в дереве: $((Count-Selection).Checked)
Добавлено новых: $added
Удалено управляемых исключений: $removedFromBackup
Уже было в базе: $($stats.Already)
Не отмечено: $($stats.Skipped)
Отсутствуют на диске: $($stats.Missing)
Осталось ручных EXE вне сканирования: $($plan.ManualCount)
Всего уникальных EXE в backup: $($plan.TotalExe)
Устранено дубликатов: $($plan.Duplicates.Count)

Backup:
$out

$saveNote

Для следующего обновления экспортируйте свежий backup из AmneziaVPN.
"@
        $r2 = [System.Windows.Forms.MessageBox]::Show(
            $msg + "`n`nОткрыть папку с файлами?",
            "Готово", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($r2 -eq "Yes") { Start-Process explorer.exe "/select,`"$out`"" }
        return $true
    } catch {
        Log "ОШИБКА: $_"
        [void][System.Windows.Forms.MessageBox]::Show(($_ | Out-String), "Ошибка")
        return $false
    }
}

function Rebuild-Database {
    $removed = 0
    $restored = 0

    $script:folders = @(Normalize-FolderList $script:folders)
    Invalidate-ExeCache

    $toRemove = @()
    foreach ($p in $script:selected.PSObject.Properties) {
        if (-not (Test-PathInAnyConfiguredFolder $p.Name $script:folders) -and
            -not (@($script:manualApps | Where-Object { (Get-PathKey $_) -eq (Get-PathKey $p.Name) }).Count -gt 0)) {
            $toRemove += $p.Name
        }
    }

    foreach ($k in $toRemove) {
        if ($script:selected.PSObject.Properties[$k]) {
            $script:selected.PSObject.Properties.Remove($k)
            $removed++
        }
    }

    foreach ($folder in $script:folders) {
        if (-not (Test-Path -LiteralPath $folder -PathType Container)) { continue }
        $exeList = @(Get-CachedExeFiles -folder $folder)
        if ($script:scanState[(Get-PathKey $folder)] -ne 'OK') {
            Write-Log "Rebuild-Database: incomplete scan for $folder; preserving existing selection"
            continue
        }
        foreach ($fi in $exeList) {
            $key = (Get-PathKey $fi.FullName)
            if (-not $script:selected.PSObject.Properties[$key]) {
                $script:selected | Add-Member -MemberType NoteProperty -Name $key -Value $true -Force
                $restored++
            }
        }
    }

    $stale = Clean-StaleSelected
    $removed += $stale

    Save-State
    Rebuild-Tree
    return @{ Removed = $removed; Restored = $restored }
}


function Set-FolderCheckedState([string]$folderPath, [bool]$checked) {
    foreach ($p in $script:selected.PSObject.Properties) {
        if (Test-PathWithinFolder $p.Name $folderPath) { $p.Value = $checked }
    }
}
function Set-TreeChildrenChecked($node, [bool]$checked) {
    foreach ($child in $node.Nodes) {
        if ($child.Tag -and $child.Tag.Type -eq 'Excluded') { continue }
        $child.Checked = $checked
        Set-TreeChildrenChecked $child $checked
    }
}
function Update-ParentChecks($node) {
    while ($node) {
        $total = 0; $checked = 0
        foreach ($p in $script:selected.PSObject.Properties) {
            if ($node.Tag.Type -eq 'ManualRoot') { continue }
            if (Test-PathWithinFolder $p.Name $node.Tag.Path) {
                $total++; if ($p.Value) { $checked++ }
            }
        }
        $node.Checked = ($total -gt 0 -and $total -eq $checked)
        $node = $node.Parent
    }
}

# ---- Дерево: чекбоксы ----
$tree.Add_AfterCheck({
    param($sender, $e)
    if ($script:treeUpdating) { return }
    $node = $e.Node
    if (-not $node.Tag) { return }
    if ($node.Tag.Type -eq 'ManualRoot') {
        $script:treeUpdating = $true
        try { $node.Checked = $false } finally { $script:treeUpdating = $false }
        return
    }
    if ($node.Tag.Type -eq 'Excluded') {
        $script:treeUpdating = $true
        try { $node.Checked = $false } finally { $script:treeUpdating = $false }
        return
    }
    $script:treeUpdating = $true
    try {
        if ($node.Tag.Type -eq 'Exe') {
            $prop = $script:selected.PSObject.Properties[$node.Tag.Key]
            if ($prop) { $prop.Value = $node.Checked }
        } else {
            Set-FolderCheckedState $node.Tag.Path $node.Checked
            Set-TreeChildrenChecked $node $node.Checked
        }
        Update-ParentChecks $node.Parent
    } finally { $script:treeUpdating = $false }
    Schedule-Save
    Update-InfoLabel
})


# ---- Фильтр: debounce prevents complete tree rebuild on every keystroke ----
$script:filterTimer = New-Object System.Windows.Forms.Timer
$script:filterTimer.Interval = 260
$script:filterTimer.Add_Tick({
    $script:filterTimer.Stop()
    if (-not $script:treeUpdating) {
        Rebuild-Tree -filterText (Get-FilterText)
    }
})
$txtMainFilter.Add_TextChanged({
    if ($script:filterIsPlaceholder) { return }
    $script:filterTimer.Stop()
    $script:filterTimer.Start()
})



# ---- ПКМ ----
$menuTree = New-Object System.Windows.Forms.ContextMenuStrip
$menuTree.BackColor = $C.PanelRaised
$menuTree.ForeColor = $C.Text
$menuTree.ShowImageMargin = $false
$menuTree.RenderMode = [System.Windows.Forms.ToolStripRenderMode]::Professional

$miOpenFolder = New-Object System.Windows.Forms.ToolStripMenuItem("Открыть папку")
$miOpenFolder.BackColor = $C.PanelRaised
$miOpenFolder.ForeColor = $C.Text
$menuTree.Items.Add($miOpenFolder) | Out-Null

$miOpenFile = New-Object System.Windows.Forms.ToolStripMenuItem("Открыть папку с файлом")
$miOpenFile.BackColor = $C.PanelRaised
$miOpenFile.ForeColor = $C.Text
$menuTree.Items.Add($miOpenFile) | Out-Null

$miRescan = New-Object System.Windows.Forms.ToolStripMenuItem("Пересканировать")
$miRescan.BackColor = $C.PanelRaised
$miRescan.ForeColor = $C.Text
$menuTree.Items.Add($miRescan) | Out-Null

$miRemoveManual = New-Object System.Windows.Forms.ToolStripMenuItem('Удалить EXE из менеджера')
$miRemoveManual.ForeColor = $C.Danger
$menuTree.Items.Add($miRemoveManual) | Out-Null

$miRemoveFolder = New-Object System.Windows.Forms.ToolStripMenuItem("Удалить папку")
$miRemoveFolder.BackColor = $C.PanelRaised
$miRemoveFolder.ForeColor = $C.Danger
$menuTree.Items.Add($miRemoveFolder) | Out-Null

$miExcludeFolder = New-Object System.Windows.Forms.ToolStripMenuItem("Пропускать эту папку и всё внутри")
$menuTree.Items.Add($miExcludeFolder) | Out-Null
$miIncludeFolder = New-Object System.Windows.Forms.ToolStripMenuItem("Вернуть папку в сканирование")
$menuTree.Items.Add($miIncludeFolder) | Out-Null

$menuTree.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null

$miUpdateAll = New-Object System.Windows.Forms.ToolStripMenuItem("Обновить всю базу")
$miUpdateAll.BackColor = $C.PanelRaised
$miUpdateAll.ForeColor = $C.Text
$menuTree.Items.Add($miUpdateAll) | Out-Null

$miHistory = New-Object System.Windows.Forms.ToolStripMenuItem('История операций')
$menuTree.Items.Add($miHistory) | Out-Null
$miRestore = New-Object System.Windows.Forms.ToolStripMenuItem('Восстановить предыдущий backup')
$menuTree.Items.Add($miRestore) | Out-Null
$menuTree.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null

$miCheckAll = New-Object System.Windows.Forms.ToolStripMenuItem("Отметить всё")
$miCheckAll.BackColor = $C.PanelRaised
$miCheckAll.ForeColor = $C.Text
$menuTree.Items.Add($miCheckAll) | Out-Null

$miUncheckAll = New-Object System.Windows.Forms.ToolStripMenuItem("Снять все отметки")
$miUncheckAll.BackColor = $C.PanelRaised
$miUncheckAll.ForeColor = $C.Text
$menuTree.Items.Add($miUncheckAll) | Out-Null

$menuTree.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null

$miExpandAll = New-Object System.Windows.Forms.ToolStripMenuItem("Развернуть всё")
$miExpandAll.BackColor = $C.PanelRaised
$miExpandAll.ForeColor = $C.Text
$menuTree.Items.Add($miExpandAll) | Out-Null

$miCollapseAll = New-Object System.Windows.Forms.ToolStripMenuItem("Свернуть всё")
$miCollapseAll.BackColor = $C.PanelRaised
$miCollapseAll.ForeColor = $C.Text
$menuTree.Items.Add($miCollapseAll) | Out-Null

$tree.ContextMenuStrip = $menuTree

# Активируем только релевантные пункты в зависимости от выбранного узла
$menuTree.Add_Opening({
    $node = $tree.SelectedNode
    $isFolder = ($node -and $node.Tag -and $node.Tag.Type -in @("Folder","Subfolder","Excluded"))
    $isExe    = ($node -and $node.Tag -and $node.Tag.Type -eq "Exe")
    $hasNode  = ($isFolder -or $isExe)
    $hasTree  = ($tree.Nodes.Count -gt 0)

    $miExcludeFolder.Enabled = ($node -and $node.Tag -and $node.Tag.Type -eq "Subfolder")
    $miIncludeFolder.Enabled = ($node -and $node.Tag -and $node.Tag.Type -eq "Excluded")
    $miOpenFolder.Enabled  = $isFolder
    $miOpenFile.Enabled    = $isExe
    $miRescan.Enabled      = $hasNode
    $miRemoveFolder.Enabled = ($node -and $node.Tag -and $node.Tag.Type -eq "Folder")
    $miRemoveManual.Enabled = ($isExe -and $node.Tag.Manual)
    $miUpdateAll.Enabled   = $true
    $miCheckAll.Enabled    = $hasTree
    $miUncheckAll.Enabled  = $hasTree
    $miExpandAll.Enabled   = $hasTree
    $miCollapseAll.Enabled = $hasTree
})

$tree.Add_MouseDown({
    param($sender, $e)
    if ($e.Button -eq [System.Windows.Forms.MouseButtons]::Right) {
        $hit = $sender.HitTest($e.Location)
        if ($hit -and $hit.Node) {
            $sender.SelectedNode = $hit.Node
            $hit.Node.EnsureVisible()
        }
    }
})

$miOpenFolder.Add_Click({
    $node = $tree.SelectedNode
    if (-not $node) { return }
    if ($node.Tag -and $node.Tag.Type -in @("Folder", "Subfolder", "Excluded")) {
        Start-Process explorer.exe "`"$($node.Tag.Path)`""
    }
})

$miOpenFile.Add_Click({
    $node = $tree.SelectedNode
    if (-not $node) { return }
    if ($node.Tag -and $node.Tag.Type -eq "Exe") {
        Start-Process explorer.exe "/select,`"$($node.Tag.Path)`""
    }
})

$miRescan.Add_Click({
    Log 'Запрошено повторное фоновое сканирование'
    Start-BackgroundRefresh
})

$miRemoveManual.Add_Click({
    $node = $tree.SelectedNode
    if (-not $node -or -not $node.Tag.Manual) { return }
    $path = [string]$node.Tag.Path
    $answer = [System.Windows.Forms.MessageBox]::Show("Удалить EXE из управления и следующего backup?`n`n$path",
        'Удаление EXE', [System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    $key = Get-PathKey $path
    $script:manualApps = @($script:manualApps | Where-Object { (Get-PathKey $_) -ne $key })
    if ($script:selected.PSObject.Properties[$key]) { $script:selected.PSObject.Properties.Remove($key) }
    $script:deletedApps = @($script:deletedApps + $path | Select-Object -Unique)
    Save-State
    Rebuild-Tree
})
$miRemoveFolder.Add_Click({ Remove-SelectedFolder })
$miExcludeFolder.Add_Click({
    $node = $tree.SelectedNode
    if (-not $node -or $node.Tag.Type -ne 'Subfolder') { return }
    $dir = [string]$node.Tag.Path
    $r = [System.Windows.Forms.MessageBox]::Show("Прекратить сканировать папку и всё внутри?`n$dir`n`nЕё EXE, добавленные Folder Manager, будут исключены из следующего backup.","Исключить папку",[System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($r -ne 'Yes') { return }
    $script:excludedFolders = @($script:excludedFolders | Where-Object { -not (Test-PathWithinFolder $_ $dir) }) + @($dir)
    Invalidate-ExeCache
    [void](Clean-StaleSelected)
    Save-State
    Rebuild-Tree
})
$miIncludeFolder.Add_Click({
    $node = $tree.SelectedNode
    if (-not $node -or $node.Tag.Type -ne 'Excluded') { return }
    $dir = [string]$node.Tag.Path
    $script:excludedFolders = @($script:excludedFolders | Where-Object { (Get-PathKey $_) -ne (Get-PathKey $dir) })
    Invalidate-ExeCache
    [void](Do-UpdateOnly)
})

$miUpdateAll.Add_Click({
    Log 'Обновление базы: фоновое сканирование'
    Start-BackgroundRefresh
})

$miCheckAll.Add_Click({
    foreach ($p in $script:selected.PSObject.Properties) { $p.Value = $true }
    Rebuild-Tree
    Schedule-Save
})
$miUncheckAll.Add_Click({
    foreach ($p in $script:selected.PSObject.Properties) { $p.Value = $false }
    Rebuild-Tree
    Schedule-Save
})


$miExpandAll.Add_Click({ $tree.ExpandAll() })
$miCollapseAll.Add_Click({ $tree.CollapseAll() })
$miHistory.Add_Click({ Show-OperationHistory })
$miRestore.Add_Click({ Restore-PreviousBackup })

# ---- Asynchronous folder scan; WinForms is only accessed from the UI timer. ----
$script:scanWork = $null
$script:scanTimer = New-Object System.Windows.Forms.Timer
$script:scanTimer.Interval = 140
$script:scanTimer.Add_Tick({
    $job = $script:scanWork
    if (-not $job) { $script:scanTimer.Stop(); return }
    if (-not $job.Async.IsCompleted) {
        try {
            $count = [int]$job.Progress['folders']
            $files = [int]$job.Progress['files']
            $lblInfo.Text = "Фоновое сканирование: папок $count, EXE $files"
        } catch { }
        return
    }
    $script:scanTimer.Stop()
    $completed = $false
    try {
        $snapshots = @($job.PS.EndInvoke($job.Async))
        if ($job.Cancel.IsCancellationRequested) {
            $script:pendingBackupPath = $null
            Log 'Сканирование отменено'
            return
        }
        Invalidate-ExeCache
        $new = 0
        foreach ($snapshot in $snapshots) {
            $key = Get-PathKey ([string]$snapshot.Root)
            $script:scanState[$key] = [string]$snapshot.State
            $items = @($snapshot.Files)
            # Reuse even incomplete snapshots in the UI; a future refresh retries them.
            $script:exeCache[$key] = @{ Files=$items }
            foreach ($file in $items) {
                $pathKey = Get-PathKey ([string]$file.FullName)
                if (-not $script:selected.PSObject.Properties[$pathKey]) {
                    $script:selected | Add-Member -MemberType NoteProperty -Name $pathKey -Value $true
                    $new++
                }
            }
        }
        $discoveredKeys = @{}
        foreach ($snapshot in $snapshots) { foreach ($file in @($snapshot.Files)) { $discoveredKeys[(Get-PathKey ([string]$file.FullName))] = $true } }
        $script:deletedApps = @($script:deletedApps | Where-Object { -not $discoveredKeys.ContainsKey((Get-PathKey $_)) })
        # Incomplete scans remain visible and are never treated as complete.
        $removed = Clean-StaleSelected
        Save-State
        Rebuild-Tree
        Write-OperationHistory 'SCAN' ("Added=$new Removed=$removed")
        Log "Фоновое сканирование: добавлено $new, удалено отсутствующих $removed"
        $completed = $true
    } catch {
        Log "Ошибка фонового сканирования: $_"
        [void][System.Windows.Forms.MessageBox]::Show("Ошибка фонового сканирования: $_", 'Ошибка')
    } finally {
        try { $job.PS.Dispose(); $job.Cancel.Dispose() } catch { }
        $script:scanWork = $null
        Set-UiBusy $false $null
        $btnRefresh.Text = 'Обновить список  (F5)'
        if ($completed -and $script:pendingBackupPath) {
            $backupToCreate = [string]$script:pendingBackupPath
            $script:pendingBackupPath = $null
            [void](Complete-CreateBackup $backupToCreate)
        } elseif (-not $completed) {
            $script:pendingBackupPath = $null
        }
    }
})

function Start-BackgroundRefresh {
    if ($script:scanWork) { return }
    if (@($script:folders).Count -eq 0) {
        Rebuild-Tree
        if ($script:pendingBackupPath) {
            $backupToCreate = [string]$script:pendingBackupPath
            $script:pendingBackupPath = $null
            [void](Complete-CreateBackup $backupToCreate)
        }
        return
    }
    $ps = [System.Management.Automation.PowerShell]::Create()
    $cancel = New-Object System.Threading.CancellationTokenSource
    $progress = New-Object 'System.Collections.Concurrent.ConcurrentDictionary[string,int]'
    $code = @'
param([string[]]$roots,[string[]]$exclude,[System.Threading.CancellationTokenSource]$cancel,$progress)
function IsExcluded([string]$candidate) {
    foreach ($e in $exclude) {
        $p = $e.TrimEnd('\')
        if ($candidate.Equals($p,[System.StringComparison]::OrdinalIgnoreCase) -or
            $candidate.StartsWith($p+'\',[System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
}
$dirsCount = 0
$filesCount = 0
foreach ($root in $roots) {
    if ($cancel.IsCancellationRequested) { break }
    $files = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
    $state = 'OK'
    if (-not [System.IO.Directory]::Exists($root)) { $state = 'UNAVAILABLE' }
    else {
        $queue = New-Object 'System.Collections.Generic.Queue[string]'
        $queue.Enqueue($root)
        while ($queue.Count -gt 0) {
            if ($cancel.IsCancellationRequested) { break }
            $current = $queue.Dequeue()
            if (IsExcluded $current) { continue }
            $dirsCount++
            $progress['folders'] = $dirsCount
            try {
                foreach ($sub in [System.IO.Directory]::EnumerateDirectories($current)) {
                    if ($cancel.IsCancellationRequested) { break }
                    $info = [System.IO.DirectoryInfo]::new($sub)
                    if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                    if (-not (IsExcluded $sub)) { $queue.Enqueue($sub) }
                }
            } catch { $state = 'PARTIAL' }
            try {
                foreach ($name in [System.IO.Directory]::EnumerateFiles($current,'*.exe')) {
                    if ($cancel.IsCancellationRequested) { break }
                    $info = [System.IO.FileInfo]::new($name)
                    if (($info.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
                    [void]$files.Add($info)
                    $filesCount++
                }
                $progress['files'] = $filesCount
            } catch { $state = 'PARTIAL' }
        }
    }
    [PSCustomObject]@{ Root=$root; State=$state; Files=@($files.ToArray()) }
}
'@
    try {
        [void]$ps.AddScript($code).AddArgument([string[]]$script:folders).AddArgument([string[]]$script:excludedFolders).AddArgument($cancel).AddArgument($progress)
        $handle = $ps.BeginInvoke()
        $script:scanWork = @{ PS=$ps; Async=$handle; Cancel=$cancel; Progress=$progress }
        Set-UiBusy $true 'Запущено фоновое сканирование...'
        $btnRefresh.Enabled = $true
        $btnRefresh.Text = 'Отменить сканирование'
        $script:scanTimer.Start()
    } catch {
        $ps.Dispose(); $cancel.Dispose()
        $script:scanWork = $null
        Set-UiBusy $false $null
        Log "Не удалось запустить фоновое сканирование: $_"
    }
}

# ---- Кнопки ----
$btnAdd.Add_Click({
    $d = New-Object System.Windows.Forms.FolderBrowserDialog
    $d.Description = "Выберите папку игры или программы"
    if ($d.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
    Add-OneFolder $d.SelectedPath
})

$btnRefresh.Add_Click({
    if ($script:scanWork -and -not $script:scanWork.Async.IsCompleted) {
        $script:scanWork.Cancel.Cancel()
        $lblInfo.Text = 'Отмена сканирования...'
        return
    }
    Start-BackgroundRefresh
})

function Remove-SelectedFolder {
    $node = $tree.SelectedNode
    if (-not $node) {
        [void][System.Windows.Forms.MessageBox]::Show("Выберите папку в дереве.")
        return
    }
    $folder = $null
    if ($node.Tag -and $node.Tag.Type -eq "Folder") { $folder = $node.Tag.Path }
    elseif ($node.Parent -and $node.Parent.Tag -and $node.Parent.Tag.Type -eq "Folder") { $folder = $node.Parent.Tag.Path }
    if (-not $folder) { return }
    $r = [System.Windows.Forms.MessageBox]::Show(
        "Удалить папку из списка?`n$folder`n`n(все её .exe тоже удалятся из базы)",
        "Подтверждение", [System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($r -ne "Yes") { return }

    # Before discarding the root, snapshot every EXE it ever controlled.
    # Both checked and unchecked entries must be removed from the source
    # backup and must not be reimported as manual on a subsequent open.
    $owned = @{}
    foreach ($p in @($script:managedApps)) {
        if (Test-PathWithinFolder ([string]$p) $folder) { $owned[(Get-PathKey $p)] = [string]$p }
    }
    foreach ($p in @($script:selected.PSObject.Properties)) {
        if (Test-PathWithinFolder ([string]$p.Name) $folder) { $owned[(Get-PathKey $p.Name)] = [string]$p.Name }
    }
    foreach ($p in @($script:manualApps)) {
        if (Test-PathWithinFolder ([string]$p) $folder) { $owned[(Get-PathKey $p)] = [string]$p }
    }
    Remember-ManagedFolder $folder @($owned.Values)
    foreach ($key in @($owned.Keys)) {
        if ($script:selected.PSObject.Properties[$key]) { $script:selected.PSObject.Properties.Remove($key) }
    }
    $script:manualApps = @($script:manualApps | Where-Object { -not (Test-PathWithinFolder ([string]$_) $folder) })
    # DeletedApps is a persistent suppression list for old input exports.
    $script:deletedApps = @($script:deletedApps + @($owned.Values) | Select-Object -Unique | Select-Object -Last 5000)
    $script:managedApps = @($script:managedApps + @($owned.Values) | Select-Object -Unique)

    $script:folders = @(Normalize-FolderList @($script:folders | Where-Object {
        -not [string]::Equals((Normalize-FullPath $_), (Normalize-FullPath $folder), [System.StringComparison]::OrdinalIgnoreCase)
    }))
    foreach ($savedProfile in @($script:backupProfiles)) {
        if ($savedProfile -and $savedProfile.PSObject.Properties['ScanFolders']) {
            $savedProfile.ScanFolders = @($savedProfile.ScanFolders | Where-Object {
                -not (Test-PathWithinFolder ([string]$_) ([string]$folder))
            })
        }
    }

    [void](Rebuild-Database)
    Invalidate-ExeCache
    $null = Save-State
    Log "Удалена папка: $folder; прежних управляемых EXE отмечено к удалению: $($owned.Count)"
}

$btnOpenBackup.Add_Click({
    try {
        $null = Select-SourceBackup
    } catch {
        $details = ($_ | Out-String)
        Log "Ошибка открытия backup: $details"
        $null = [System.Windows.Forms.MessageBox]::Show("Не удалось открыть backup. Подробности записаны в журнал.`n`n$($_.Exception.Message)", 'Ошибка открытия backup')
    }
})

$btnBackup.Add_Click({
    try {
        Log "=== Backup ==="
        $null = Do-CreateBackup
    } catch {
        $details = ($_ | Out-String)
        Log "Ошибка создания backup: $details"
        $null = [System.Windows.Forms.MessageBox]::Show("Не удалось создать backup. Подробности записаны в журнал.`n`n$($_.Exception.Message)", 'Ошибка создания backup')
    }
})

$btnHelp.Add_Click({ [void](Show-IntroWindow $false) })

# ---- Автопроверка обновлений ----
function Check-Updates {
    try {
        $lastStr = [string]$cfg.LastUpdateCheck
        if ($lastStr) {
            $last = [datetime]::Parse($lastStr)
            if (((Get-Date) - $last).TotalHours -lt 6) {
                $cachedTag = [string]$cfg.LatestKnownTag
                if ($cachedTag -and (Test-VersionString $cachedTag $AppVersion)) {
                    return @{ Ok = $true; Latest = $cachedTag; Cached = $true; HasUpdate = $true }
                }
                return @{ Ok = $true; Latest = $cachedTag; Cached = $true; HasUpdate = $false }
            }
        }
    } catch { }

    Log "Проверяю обновления на GitHub..."
    $resp = Get-LatestRelease
    if (-not $resp) {
        Log "Не удалось проверить обновления"
        return @{ Ok = $false; Latest = $null; HasUpdate = $false }
    }
    $latestTag = [string]$resp.tag_name
    if ([string]::IsNullOrWhiteSpace($latestTag)) {
        Log "Ответ GitHub без tag_name"
        return @{ Ok = $false; Latest = $null; HasUpdate = $false }
    }

    try {
        $newLastCheck = (Get-Date).ToString("o")
        if ($cfg.LastUpdateCheck -ne $newLastCheck -or $cfg.LatestKnownTag -ne $latestTag) {
            $cfg.LastUpdateCheck = $newLastCheck
            $cfg.LatestKnownTag  = $latestTag
            [void](Save-Config $cfg)
        }
    } catch { }

    $hasUpdate = Test-VersionString $latestTag $AppVersion
    if ($hasUpdate) {
        Log "Доступна новая версия: $latestTag"
    } else {
        Log "Установлена последняя версия ($AppVersion)"
    }
    return @{ Ok = $true; Latest = $latestTag; Url = $resp.html_url; HasUpdate = $hasUpdate }
}

# ---- Drag&Drop ----
$tree.Add_DragEnter({
    param($sender, $e)
    if ($e.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) {
        $e.Effect = [System.Windows.Forms.DragDropEffects]::Copy
    } else {
        $e.Effect = [System.Windows.Forms.DragDropEffects]::None
    }
})
$tree.Add_DragDrop({
    param($sender, $e)
    $paths = $e.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop)
    foreach ($p in $paths) {
        if (Test-Path -LiteralPath $p -PathType Container) {
            Add-OneFolder $p
        } else {
            Log "Пропуск (не папка): $p"
        }
    }
})

# ---- Выравнивание ----
function Update-Layout {
    # Все размеры рассчитываются из доступного пространства окна.
    # Это предотвращает уход журнала за нижний край при небольшом экране.
    $w = $form.ClientSize.Width
    $h = $form.ClientSize.Height
    if ($w -lt (Scaled 600) -or $h -lt (Scaled 450)) { return }

    $pad = Scaled 12
    $contentW = [Math]::Max((Scaled 350), $w - 2 * $pad)
    $pnlTop.Width = $w
    $pnlAccent.Width = $w

    $helpW = Scaled 34
    $filterLeft = Scaled 90
    $rightPad = Scaled 14
    $txtMainFilter.Left = $filterLeft
    $txtMainFilter.Width = [Math]::Max((Scaled 180), $w - $filterLeft - $helpW - $rightPad - (Scaled 10))
    $btnHelp.Left = $txtMainFilter.Right + (Scaled 10)
    $btnHelp.Width = $helpW

    $btnAdd.Left = $pad
    $btnRefresh.Left = $btnAdd.Right + (Scaled 10)
    # Keep both action buttons visible at the minimum supported window width.
    $btnRefresh.Width = [Math]::Min((Scaled 190), [Math]::Max((Scaled 140), $contentW - $btnAdd.Width - (Scaled 10)))
    $btnOpenBackup.Left = $pad
    $btnBackup.Left = $btnOpenBackup.Right + (Scaled 10)
    $btnBackup.Width = [Math]::Min((Scaled 240), [Math]::Max((Scaled 185), $contentW - $btnOpenBackup.Width - (Scaled 10)))

    $tree.Left = $pad
    $tree.Width = $contentW
    $lblTreeSection.Left = $pad + (Scaled 2)
    # At narrow widths hide the explanatory text instead of overlapping the heading.
    $lblTreeHint.Visible = ($contentW -gt (Scaled 620))
    $lblTreeHint.Left = [Math]::Min((Scaled 430), [int]($w * 0.49))
    $lblTreeHint.Width = [Math]::Max((Scaled 120), $w - $lblTreeHint.Left - $pad)
    $tree.Top = Scaled 130

    # Журнал получает не менее 110 px, дерево — оставшееся место.
    $minLogH = Scaled 110
    $desiredLogH = Scaled 185
    $logH = [Math]::Max($minLogH, [Math]::Min($desiredLogH, [int]($h * 0.27)))
    $bottomPad = Scaled 12
    $txtLog.Left = $pad
    $txtLog.Width = $contentW
    $txtLog.Height = $logH
    $txtLog.Top = $h - $bottomPad - $logH
    $lblLog.Top = $txtLog.Top - (Scaled 23)
    $lblLogHint.Top = $lblLog.Top
    $btnBackup.Top = $lblLog.Top - (Scaled 51)
    $btnOpenBackup.Top = $btnBackup.Top
    $pnlStats.Left = $pad
    $pnlStats.Top = $btnBackup.Top - (Scaled 54)
    $pnlStats.Width = $contentW
    $lblInfo.Width = [Math]::Max((Scaled 100), $contentW - (Scaled 24))
    $lblLast.Width = $lblInfo.Width
    $tree.Height = [Math]::Max((Scaled 130), $pnlStats.Top - $tree.Top - (Scaled 8))
}

$form.Add_Shown({ Update-Layout })
$form.Add_Resize({ Update-Layout })

# ---- Запуск ----
# First scan starts after the window is visible; the UI stays responsive.
$form.Add_Shown({ Start-BackgroundRefresh })
Log "Загружено. Папок: $($script:folders.Count), отмечено EXE: $((Count-Selection).Checked)"
Log "Масштаб интерфейса: $($script:UiScale)x (DPI: $($script:DpiScale))"
Log "Автор: $AppAuthor"

$updateTimer = New-Object System.Windows.Forms.Timer
$updateTimer.Interval = 2000
$updateTimer.Add_Tick({
    $updateTimer.Stop()
    $updateTimer.Dispose()
    try {
        $res = Check-Updates
        if ($res.Ok -and $res.HasUpdate) {
            $msg = "Доступна новая версия: $($res.Latest)`nУ вас установлена: $AppVersion`n`nОткрыть страницу загрузки?"
            $r = [System.Windows.Forms.MessageBox]::Show($msg, "Есть обновление",
                [System.Windows.Forms.MessageBoxButtons]::YesNo,
                [System.Windows.Forms.MessageBoxIcon]::Information)
            if ($r -eq "Yes") {
                $url = $res.Url
                if (-not $url) { $url = "https://github.com/$RepoOwner/$RepoName/releases/latest" }
                Start-Process $url
                Log "Открыл страницу релиза"
            }
        }
    } catch { Write-Log "Check-Updates error: $_" }
})
$form.Add_Shown({
    try { $updateTimer.Start() } catch { }
})

$form.Add_FormClosing({
    if ($script:scanWork) {
        try { $script:scanWork.Cancel.Cancel() } catch { }
        $script:pendingBackupPath = $null
        # The background operation must not change UI after the window closes.
        $script:scanTimer.Stop()
    }
})
Write-Log "Showing main window"
[void]$form.ShowDialog()

if ($script:pendingSave) {
    $script:pendingSave = $false
    Save-State
}

try {
    if ($script:mutex) {
        $script:mutex.ReleaseMutex()
        $script:mutex.Dispose()
    }
} catch { }

Write-Log "=== END ==="
exit 0
